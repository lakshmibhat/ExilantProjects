
//
//  recentViewController.m
//  MusicAppProject
//
//  Created by lakshmi r bhat on 30/12/15.
//  Copyright © 2015 lakshmi r bhat. All rights reserved.
//

#import "recentViewController.h"
#import "SongItems.h"
@interface recentViewController ()

@end

@implementation recentViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    SongItems *item3=[[SongItems alloc]initWithImage:[NSImage imageNamed:@"song1.jpg"] andTitle:@"recent1"];
    SongItems *item4=[[SongItems alloc]initWithImage:[NSImage imageNamed:@"sopng2.jpg"] andTitle:@"recent2"];
    // Do view setup here.
    NSMutableArray *items=[NSMutableArray arrayWithObjects:item3,item4, nil];
    self.subList=items;
    // Do view setup here.
}
-(NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(nullable NSTableColumn *)tableColumn row:(NSInteger)row{
    
    
    NSTableCellView *cellView=[tableView makeViewWithIdentifier:tableColumn.identifier owner:self];
    
    
    if ([tableColumn.identifier isEqualToString:@"subList"]) {
        SongItems *subItems= [self.subList objectAtIndex:row];
        cellView.imageView.image=subItems.image;
        cellView.textField.stringValue=subItems.songTitle;
        return cellView;
        
    }
    return cellView;
}
-(NSInteger)numberOfRowsInTableView:(NSTableView *)tableView{
    return [self.subList count];
    
    
}
-(id)tableView:(NSTableView *)tableView objectValueForTableColumn:(nullable NSTableColumn *)tableColumn row:(NSInteger)row{
    return @"hello";
    
}

@end
