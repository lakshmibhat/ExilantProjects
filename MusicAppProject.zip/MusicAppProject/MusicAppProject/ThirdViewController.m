//
//  ThirdViewController.m
//  MusicAppProject
//
//  Created by lakshmi r bhat on 29/12/15.
//  Copyright © 2015 lakshmi r bhat. All rights reserved.
//

#import "ThirdViewController.h"
#import "SongItems.h"
#import "recentViewController.h"
@interface ThirdViewController ()

@end

@implementation ThirdViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    SongItems *item1=[[SongItems alloc]initWithImage:[NSImage imageNamed:@"subgroupimage.png"] andTitle:@"Recently added"];
    SongItems *item2=[[SongItems alloc]initWithImage:[NSImage imageNamed:@"subgroupimage.png"] andTitle:@"My favourites"];
    // Do view setup here.
    NSMutableArray *items=[NSMutableArray arrayWithObjects:item1,item2, nil];
    self.list=items;

        // Do view setup here.
}
-(NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(nullable NSTableColumn *)tableColumn row:(NSInteger)row{
    
    
    NSTableCellView *cellView=[tableView makeViewWithIdentifier:tableColumn.identifier owner:self];
    
    if ([tableColumn.identifier isEqualToString:@"playList"]) {
        SongItems *items=[self.list objectAtIndex:row];
        cellView.imageView.image=items.image;
        cellView.textField.stringValue=items.songTitle;
        return cellView;
    }
   
    return cellView;
}
-(NSInteger)numberOfRowsInTableView:(NSTableView *)tableView{
    return [self.list count];
    
    
}
-(id)tableView:(NSTableView *)tableView objectValueForTableColumn:(nullable NSTableColumn *)tableColumn row:(NSInteger)row{
    return @"hello";
    
}

-(BOOL)tableView:(NSTableView *)tableView shouldSelectRow:(NSInteger)row{
    
        recentViewController *recent=[self.storyboard instantiateControllerWithIdentifier:@"recent"];
        NSWindow *main=[NSApp mainWindow];
        main.contentViewController=recent;
    
   // [self performSegueWithIdentifier:@"recent" sender:self];
    return true;
}


@end
