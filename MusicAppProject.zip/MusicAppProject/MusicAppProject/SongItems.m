//
//  SongItems.m
//  MusicAppProject
//
//  Created by lakshmi r bhat on 29/12/15.
//  Copyright © 2015 lakshmi r bhat. All rights reserved.
//

#import "SongItems.h"

@implementation SongItems
-(id)initWithImage:image andTitle:songTitle{
    
    if (self=[super init]) {
        self.image=image;
        self.songTitle=songTitle;
    }
    return self;
}
@end
