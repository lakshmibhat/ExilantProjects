//
//  FifthViewController.h
//  MusicAppProject
//
//  Created by lakshmi r bhat on 30/12/15.
//  Copyright © 2015 lakshmi r bhat. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#import "SongItems.h"
@interface FifthViewController : NSViewController
@property SongItems *itemdelegate;
@end
