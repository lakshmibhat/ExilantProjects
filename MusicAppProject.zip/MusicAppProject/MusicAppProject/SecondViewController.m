//
//  SecondViewController.m
//  MusicAppProject
//
//  Created by lakshmi r bhat on 29/12/15.
//  Copyright © 2015 lakshmi r bhat. All rights reserved.
//

#import "SecondViewController.h"
#import "FifthViewController.h"
#import "SongItems.h"
#import "recentViewController.h"
@interface SecondViewController ()
{
    SongItems *item;
}
@end

@implementation SecondViewController

    SongItems *items;

- (void)viewDidLoad {
    [super viewDidLoad];
    SongItems *item1=[[SongItems alloc]initWithImage:[NSImage imageNamed:@"song1.jpg"] andTitle:@"first song"];
    SongItems *item2=[[SongItems alloc]initWithImage:[NSImage imageNamed:@"song2.jpg"] andTitle:@"second song"];
    SongItems *item3=[[SongItems alloc]initWithImage:[NSImage imageNamed:@"song2.jpg"] andTitle:@"second song"];
    // Do view setup here.
    NSMutableArray *items=[NSMutableArray arrayWithObjects:item1,item2,item3, nil];
    self.itemList=items;
}
-(NSView *)tableView:(NSTableView *)tableView viewForTableColumn:(nullable NSTableColumn *)tableColumn row:(NSInteger)row{
    
    
    NSTableCellView *cellView=[tableView makeViewWithIdentifier:tableColumn.identifier owner:self];
    
    if ([tableColumn.identifier isEqualToString:@"songs"]) {
        SongItems *sItems=[self.itemList objectAtIndex:row];
        cellView.imageView.image=sItems.image;
        cellView.textField.stringValue=sItems.songTitle;
        return cellView;
    }
    return cellView;
}
-(NSInteger)numberOfRowsInTableView:(NSTableView *)tableView{
    return [self.itemList count];
    
    
}
-(id)tableView:(NSTableView *)tableView objectValueForTableColumn:(nullable NSTableColumn *)tableColumn row:(NSInteger)row{
    return @"hello";
    
}
-(void)prepareForSegue:(NSStoryboardSegue *)segue sender:(id)sender{
    
        if([segue.identifier isEqual:@"player"])
        {
            FifthViewController *five=segue.destinationController;
            //sec=segue.destinationViewController;

        }

    
}
-(BOOL)tableView:(NSTableView *)tableView shouldSelectRow:(NSInteger)row{
    items=[self.itemList objectAtIndex:row];
            FifthViewController *fifth=[self.storyboard instantiateControllerWithIdentifier:@"slider"];
    NSWindow *main=[NSApp mainWindow];
    main.contentViewController=fifth;
    
//    [self performSegueWithIdentifier:@"player" sender:self];
   return true;
}
- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];
    
    
    // Update the view, if already loaded.
}
@end
