//
//  recentViewController.h
//  MusicAppProject
//
//  Created by lakshmi r bhat on 30/12/15.
//  Copyright © 2015 lakshmi r bhat. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface recentViewController : NSViewController
@property (nonatomic)NSMutableArray *subList;

@end
