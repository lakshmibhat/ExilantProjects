//
//  main.m
//  MusicAppProject
//
//  Created by lakshmi r bhat on 29/12/15.
//  Copyright © 2015 lakshmi r bhat. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
