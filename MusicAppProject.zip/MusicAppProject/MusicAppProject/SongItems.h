//
//  SongItems.h
//  MusicAppProject
//
//  Created by lakshmi r bhat on 29/12/15.
//  Copyright © 2015 lakshmi r bhat. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SongItems : NSObject
@property(strong)NSImage *image;
@property(strong)NSString *songTitle;
-(id)initWithImage:image andTitle:songTitle;
@end
