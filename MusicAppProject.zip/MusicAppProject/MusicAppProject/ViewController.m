//
//  ViewController.m
//  MusicAppProject
//
//  Created by lakshmi r bhat on 29/12/15.
//  Copyright © 2015 lakshmi r bhat. All rights reserved.
//

#import "ViewController.h"
#import "SecondViewController.h"
@interface ViewController()

//@property SecondViewController *sec;
@end
@implementation ViewController


- (void)viewDidLoad {
    [super viewDidLoad];
//    [self addChildViewController:self.sec];

    
    // Do any additional setup after loading the view.
}
- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}

@end
