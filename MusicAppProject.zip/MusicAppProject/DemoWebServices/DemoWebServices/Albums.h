//
//  Albums.h
//  DemoWebServices
//
//  Created by lakshmi r bhat on 31/12/15.
//  Copyright © 2015 lakshmi r bhat. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Albums : NSObject
@property (nonatomic)NSString *title;
@end
