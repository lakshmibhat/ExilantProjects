//
//  ViewController.m
//  DemoWebServices
//
//  Created by lakshmi r bhat on 31/12/15.
//  Copyright © 2015 lakshmi r bhat. All rights reserved.
//

#import "ViewController.h"
#import "Albums.h"
@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    // Do any additional setup after loading the view.
}

- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}
- (IBAction)fetchButton:(id)sender {
    
    NSURL *urlString=[NSURL URLWithString:@"http://jsonplaceholder.typicode.com/albums"];
    NSURLRequest *fetchRequest=[[NSURLRequest alloc]initWithURL:urlString cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:3.0];
    NSURLResponse *response=nil;
    NSError *error=nil;
    NSURLSession *session = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    __block NSDictionary *jsonDict=nil;
    [[session dataTaskWithURL:urlString completionHandler:^(NSData *data,NSURLResponse *response,NSError *error){
        NSError *parseError=nil;
        jsonDict=[NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
    }] resume];
    
}

@end
