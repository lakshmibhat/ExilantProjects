//
//  ClipBoardViewController.swift
//  NoteApp
//
//  Created by avnish kumar on 21/06/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import UIKit

extension String {
    
    func stringByAppendingPathComponent(path: String) -> String {
        
        let nsSt = self as NSString
        
        return nsSt.stringByAppendingPathComponent(path)
    }
}

class ClipBoardViewController: UIViewController,UIPopoverPresentationControllerDelegate {
    
    
    @IBOutlet var color: UIButton!
    
    @IBOutlet var style: UIButton!
    
    @IBOutlet var size: UIButton!
    
    @IBOutlet var bgColor: UIButton!
    
    
    @IBOutlet weak var containerView: UIView!
    
    var value = true
    
    var img : UIImage!
    
    var pageSize:CGSize!
    
      @IBOutlet weak var clipBoardTextView : UITextView!
    @IBOutlet weak var fontView: UIView!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        UIView.animateWithDuration(0, animations: {
            self.fontView.transform = CGAffineTransformMakeTranslation(0,-self.fontView.frame.height)
            
        }) { (value) in
            self.containerView.transform = CGAffineTransformMakeTranslation(0, -self.fontView.frame.height)
        }
    }
   func performAnimation()
   {
    
    UIView.animateWithDuration(0.2, delay: 0, options: [], animations: {
         self.containerView.transform = CGAffineTransformMakeTranslation(0,-self.fontView.frame.height)
        
        }) { (value) in
           self.fontView.transform = CGAffineTransformMakeTranslation(0, -self.fontView.frame.width)
    }

   }
    override func viewWillAppear(animated: Bool) {
        
        let searchTabViewController = self.tabBarController?.viewControllers![0] as! SearchTabViewController
        let clipboardModel = searchTabViewController.clipboardModel
        
        if clipboardModel.copiedImg != nil {
            
            let image = UIImageView(image: clipboardModel.copiedImg)
            img = clipboardModel.copiedImg
            let path = UIBezierPath(rect: CGRectMake(500, 500, image.frame.width/4, image.frame.height/4))
            clipBoardTextView.textContainer.exclusionPaths = [path]
            let attachment = NSTextAttachment()
            let resizedImage = resizeImage(clipboardModel.copiedImg!)
            attachment.image = resizedImage
            let attString = NSAttributedString(attachment: attachment)
            clipBoardTextView.textStorage.insertAttributedString(attString, atIndex: clipBoardTextView.selectedRange.location)
        }
        else{
            if clipboardModel.copiedContent != ""{
                clipBoardTextView.text = clipboardModel.copiedContent
            }
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func editFunctions(sender: UIBarButtonItem) {
        if value
        {
            
            color.setTitle("Color", forState: UIControlState.Normal)
            style.setTitle("Style", forState: UIControlState.Normal)
            size.setTitle("Size", forState: UIControlState.Normal)
            bgColor.setTitle("BG Color", forState: UIControlState.Normal)
            
         UIView.animateWithDuration(0.2) {
             self.containerView.transform = CGAffineTransformIdentity
         }
        
         UIView.animateWithDuration(0.2) {
             self.fontView.transform = CGAffineTransformIdentity
         }
            value = false
        } else {
            performAnimation()
            value = true
        }
        
    }
    
    @IBAction func annotateFunction(sender: UIBarButtonItem) {
        
        if value
        {
            color.setTitle("Highlight", forState: UIControlState.Normal)
            style.setTitle("Align", forState: UIControlState.Normal)
            size.setTitle("Shapes", forState: UIControlState.Normal)
            bgColor.setTitle("Bubble", forState: UIControlState.Normal)
            
                    UIView.animateWithDuration(0) {
                self.containerView.transform = CGAffineTransformIdentity
            }
            
            UIView.animateWithDuration(0) {
                self.fontView.transform = CGAffineTransformIdentity
            }
            value = false
        } else {
            performAnimation()
            value = true
        }
        
        
        
    }
    

    @IBAction func popover(_ sender: UIButton) {
//        if ((sender.titleLabel?.text == ("Color")) || (sender.titleLabel?.text == ("Style")) || (sender.titleLabel?.text == ("Size")) || (sender.titleLabel?.text == ("BG Color")) || (sender.titleLabel?.text == ("highlight"))){
//            
            let popupController = storyboard!.instantiateViewControllerWithIdentifier("FontNavigation") as! UINavigationController
            
           (popupController.topViewController as! FontSettingTableViewController).fontOption = sender.tag
            popupController.modalPresentationStyle = .Popover
            popupController.preferredContentSize = CGSizeMake(200, 75)
            if let popoverController = popupController.popoverPresentationController {
                let viewForSource = sender as UIView
                popoverController.sourceView = viewForSource
                popoverController.sourceRect = viewForSource.bounds
                popoverController.preferredContentSize
                popoverController.backgroundColor = UIColor.whiteColor()
                popoverController.permittedArrowDirections = .Up
                popoverController.delegate = self
                popupController.editing = false
            }
            presentViewController(popupController, animated: true, completion: nil)
//        }
//            
//        else if ((sender.titleLabel?.text == ("Align")) || (sender.titleLabel?.text == ("Highlight")) || (sender.titleLabel?.text == ("Shapes")) || (sender.titleLabel?.text == ("Bubble"))){
//            let popupController = storyboard!.instantiateViewControllerWithIdentifier("annotate") as! AnnotateSettingTableViewController
//            
//            popupController.annotateOption=sender.tag
//            popupController.modalPresentationStyle = .Popover
//            popupController.preferredContentSize = CGSizeMake(250, 100)
//            if let popoverController = popupController.popoverPresentationController {
//                let viewForSource = sender as UIView
//                popoverController.sourceView = viewForSource
//                popoverController.sourceRect = viewForSource.bounds
//                popoverController.preferredContentSize
//                popoverController.backgroundColor = UIColor.whiteColor()
//                popoverController.permittedArrowDirections = .Up
//                popoverController.delegate = self
//                popupController.editing = false
//            }
//            presentViewController(popupController, animated: true, completion: nil)
//            
//        }
        
    }
    
    
    func adaptivePresentationStyleForPresentationController(controller: UIPresentationController) -> UIModalPresentationStyle{
        return UIModalPresentationStyle.None
    }
    
    @IBAction func generatePdf(sender: AnyObject) {
      
        pageSize = CGSize(width: 850, height: 1100)
        let fileName: NSString = "kindle.pdf"
        let path:NSArray = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true)
        let DocumentDirectory: AnyObject = path.objectAtIndex(0)
        let pdfPathWithFileName = (NSTemporaryDirectory() as NSString).stringByAppendingPathComponent(fileName as String)
        
        self.generatePDFs(pdfPathWithFileName)
        
    }
    
    func generatePDFs(filePath: String) {
        
        UIGraphicsBeginPDFContextToFile(filePath, CGRect(x: 0, y: 0, width: 0, height: 0),nil)
        UIGraphicsBeginPDFPageWithInfo(CGRect(x: 0, y: 0, width: 768, height: 1024) , nil)
        
        //toPDF()
        self.drawBackground()
        
        if img != nil {
        self.drawImage()
        }
        
        self.drawText()
        UIGraphicsEndPDFContext()
    }
    
    
    // draw the custom background view to display the text and image in pdf.
    func drawBackground () {
        
//        let context:CGContext = UIGraphicsGetCurrentContext()!
//        let rect:CGRect = CGRect(x: 0, y: 0, width: pageSize.width, height: pageSize.height)
        
        
        //        context.setFillColor(UIColor.brown().cgColor)
        //        context.fill(rect)
    }
    
    
    // draw the custom textview to display the text enter into it into pdf.
    func drawText(){
        let context:CGContext = UIGraphicsGetCurrentContext()!
        let font = UIFont(name: "HelveticaNeue-UltraLight", size: CGFloat(20))!
        //        context.setFillColor(UIColor.orange().cgColor)
        let textRect : CGRect = CGRect(x: 200, y: 350, width: ((self.clipBoardTextView).frame).size.width, height: ((self.clipBoardTextView).frame).size.height)
        let myString : NSString = self.clipBoardTextView.text
        let paraStyle = NSMutableParagraphStyle()
        paraStyle.lineSpacing = 6.0
        let fieldFont = UIFont(name: "Helvetica Neue", size: 30)
        let parameters: NSDictionary = [ NSFontAttributeName:font, NSParagraphStyleAttributeName:paraStyle ,NSFontAttributeName: fieldFont!]
        myString.drawInRect(textRect, withAttributes: parameters as? [String : AnyObject])
    }
    
    
    // draw the custom image to display into pdf with the given text you enter into textview
    func drawImage(){
        let imgRect:CGRect = CGRect(x: 284, y: 50, width: 200, height: 200)
        let image : UIImage = img
        image.drawInRect(imgRect)
        
    }

    @IBAction func close(_ segue:UIStoryboardSegue) {
        
        if let fontViewController = segue.sourceViewController as?
            FontSettingTableViewController {
            switch fontViewController.fontOption {
            case 1:
                if let textColor = fontViewController.textColor {
                    clipBoardTextView.textColor = textColor
                }
            case 2:
                if let fontName = fontViewController.fontName {
                    clipBoardTextView.font = UIFont(name: fontName, size: (clipBoardTextView.font?.pointSize)!)
                }
            case 3:
                if let fontSize = fontViewController.fontSize {
                    clipBoardTextView.font = UIFont(name: clipBoardTextView.font!.fontName, size: fontSize)
                }
            case 4:
                if let backgroundColor = fontViewController.bgColor {
                    clipBoardTextView.layer.backgroundColor = backgroundColor.CGColor
                }
            case 5:
                if let highlightColor = fontViewController.highlightColor {
                    
                    let range = clipBoardTextView.selectedRange
                    let string = NSMutableAttributedString(attributedString: clipBoardTextView.attributedText)
                    let attributes = [NSBackgroundColorAttributeName: highlightColor]
                    string.addAttributes(attributes, range: clipBoardTextView.selectedRange)
                    clipBoardTextView.attributedText = string
                    clipBoardTextView.selectedRange = range
                }

            default:
                break
            }
            
        }
    }
    
    //To resize image
    func resizeImage(image: UIImage) -> UIImage{
        var actualHeight = Double(image.size.height)
        var actualWidth = Double(image.size.width)
        let maxHeight = Double(300.0)
        let maxWidth = Double(400.0)
        var imgRatio = Double(actualWidth/actualHeight)
        let maxRatio = Double(maxWidth/maxHeight)
        
        if (Double(actualHeight) > maxHeight || Double(actualWidth) > maxWidth)
        {
            if(Double(imgRatio) < maxRatio)
            {
                //adjust width according to maxHeight
                imgRatio = maxHeight / actualHeight
                actualWidth = imgRatio * actualWidth
                actualHeight = maxHeight
            }
            else if(imgRatio > maxRatio)
            {
                //adjust height according to maxWidth
                imgRatio = maxWidth / actualWidth
                actualHeight = imgRatio * actualHeight
                actualWidth = maxWidth
            }
            else
            {
                actualHeight = maxHeight
                actualWidth = maxWidth
            }
        }
        
        let rect = CGRectMake(0.0, 0.0, CGFloat(actualWidth), CGFloat(actualHeight))
        UIGraphicsBeginImageContext(rect.size)
        image.drawInRect(rect)
        let img = UIGraphicsGetImageFromCurrentImageContext()
        
        return img!
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
