//
//  BackgroundColorTableViewCell.swift
//  NoteApp
//
//  Created by swathi m on 8/8/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import UIKit

class BackgroundColorTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
