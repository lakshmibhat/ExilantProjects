//
//  FontSettingTableViewController.swift
//  NoteApp
//
//  Created by lakshmi r bhat on 25/07/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import UIKit

class FontSettingTableViewController: UITableViewController {
    var fontOption : Int = 0
    var fontSize : CGFloat!
    var textColor : UIColor!
    var bgColor : UIColor!
    var fontName : String!
    var highlightColor : UIColor!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.allowsSelection = false
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

 


    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
//
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 1
    }
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 100.0
    }

    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var cellIdentifier : String
        var cell = UITableViewCell()
        switch fontOption {
        case 1:
            cellIdentifier = "colour"
            cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier,forIndexPath: indexPath) as! FontTextColorTableViewCell
        case 2:
            cellIdentifier = "style"
            cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier,forIndexPath: indexPath) as! FontStylePickerTableViewCell
        case 3:
            cellIdentifier = "size"
            cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier,forIndexPath: indexPath) as! FontSizeTableViewCell
        case 4:
            cellIdentifier = "bgcolour"
            cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier,forIndexPath: indexPath) as! BackgroundColorTableViewCell
        case 5:
            cellIdentifier = "highlight"
            cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier,forIndexPath: indexPath)
        default:
            break
        }
       

        // Configure the cell...

        return cell
    }
    
    @IBAction func doneAction(sender: UIBarButtonItem) {
        switch fontOption {
        case 1: break
            //                        let indexpath = NSIndexPath(index: 0)
        //                        cell = tableView.cellForRowAtIndexPath(indexpath) as! FontTextColorTableViewCell!
        case 2:
            let indexpath = NSIndexPath(forRow: 0, inSection: 0)
            let cell = tableView.cellForRowAtIndexPath(indexpath) as! FontStylePickerTableViewCell!
            fontName = cell.fontNames[cell.fontPickerView.selectedRowInComponent(0)]
        case 3:
            let indexpath = NSIndexPath(forRow: 0, inSection: 0)
            let cell = tableView.cellForRowAtIndexPath(indexpath) as! FontSizeTableViewCell!
            fontSize = cell.fontSizeLabel.font.pointSize
            
        case 4: break
            //                        let indexpath = NSIndexPath(index: 3)
        //                        cell = tableView.cellForRowAtIndexPath(indexpath) as! BackgroundColorTableViewCell!
        default:
            break
        }
        performSegueWithIdentifier("unwindToClipView", sender: sender)
        
    }
    @IBAction func textColorChange(_ sender: UIButton) {
        textColor = sender.backgroundColor
        performSegueWithIdentifier("unwindToClipView", sender: sender)
    }
    
    @IBAction func bgColor(_ sender: UIButton) {
        bgColor = sender.backgroundColor
        performSegueWithIdentifier("unwindToClipView", sender: sender)
        
    }
    @IBAction func highlightColorAction(_ sender: UIButton) {
        highlightColor = sender.backgroundColor
        performSegueWithIdentifier("unwindToClipView", sender: sender)
    }
        /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
