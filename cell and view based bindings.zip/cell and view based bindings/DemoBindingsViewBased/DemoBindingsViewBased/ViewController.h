//
//  ViewController.h
//  DemoBindingsViewBased
//
//  Created by trainer mac on 22/12/15.
//  Copyright © 2015 Exilant. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController
@property (strong) IBOutlet NSArrayController *detailsArrayController;

@property(nonatomic)NSMutableArray *details;

@end

