//
//  Person.h
//  DemoCellBased
//
//  Created by trainer mac on 22/12/15.
//  Copyright © 2015 Exilant. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Person : NSObject
@property(nonatomic)NSString *name;
@property(nonatomic)int rollNo;
@end
