//
//  ViewController.m
//  DemoBindingsViewBased
//
//  Created by trainer mac on 22/12/15.
//  Copyright © 2015 Exilant. All rights reserved.
//

#import "ViewController.h"
#import "Person.h"
@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    
    Person *p1 = [[Person alloc]init];
    p1.name = @"Steve";
    
    p1.rollNo = 890;
    
    Person *p2 = [[Person alloc]init];
    p2.name = @"Jobs";
    
    p2.rollNo = 89;
    
    
    Person *p3 = [[Person alloc]init];
    p3.name = @"Raghu";
    
    p3.rollNo = 99;
    
    self.details = [[NSMutableArray alloc]init];
    
//    [self.details addObject:p1];
//    [self.details addObject:p2];
//    [self.details addObject:p3];
    
    [self.detailsArrayController addObject:p1];
    
    [self.detailsArrayController addObject:p2];
    
    [self.detailsArrayController addObject:p3];
    
    
    // Do any additional setup after loading the view.
}

- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}

@end
