//
//  ViewController.m
//  DemoCellBased
//
//  Created by trainer mac on 22/12/15.
//  Copyright © 2015 Exilant. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.details = [[NSMutableArray alloc]init];
    
    
    // Do any additional setup after loading the view.
}

- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}

@end
