//
//  Person.m
//  DemoCellBased
//
//  Created by trainer mac on 22/12/15.
//  Copyright © 2015 Exilant. All rights reserved.
//

#import "Person.h"

@implementation Person

-(instancetype)init{
    
    if (self=[super init]) {
        
        _name = @"Steve";
        _rollNo = 109;
        
    }
    return self;
    
}

@end
