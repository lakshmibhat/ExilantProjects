//
//  AppController.swift
//  DontSleep
//
//  Created by avnish kumar on 01/02/16.
//  Copyright © 2016 avnish kumar. All rights reserved.
//

import Cocoa

class AppController: NSObject,NSMenuDelegate,NSUserNotificationCenterDelegate
{
    //The associated SleepWakeTimer instance of this app controller.
    var sleepWakeTimer:SleepWakeTimer!
    var batteryStatus:BatteryStatus!
    var batteryOverrideEnabled:Bool = false
    
    
    @IBOutlet weak var menu: NSMenu!
    @IBOutlet weak var timerMenu: NSMenu!
    
    // Status Item
    let statusItem = NSStatusBar.systemStatusBar().statusItemWithLength(NSVariableStatusItemLength)
    
    override init()
    {
        
        super.init()
        
        self.configureStatusItem()
        self.batteryStatus = BatteryStatus()
        self.batteryStatus.capacityChangeHandler = { [weak self]
            (capacity:Float)->Void in
            self?.batteryCapacityDidChange(capacity)
        }
        
        self.sleepWakeTimer=SleepWakeTimer()
        self.sleepWakeTimer.addObserver(self, forKeyPath:"scheduled", options:NSKeyValueObservingOptions.New, context:nil);
       
        if(shouldActivateOnLaunch())
        {
            self .activateTimer()
        }
        
       
       self.configureBatteryStatus()
        
        
    }
    
    
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
       
    }
    
    deinit{
        
       NSNotificationCenter.defaultCenter().removeObserver(self, name: DSBatteryCapacityThresholdDidChangeNotification, object: nil)
    }
    
    
    
    func configureStatusItem()
    {
        statusItem.highlightMode = !NSUserDefaults.standardUserDefaults().boolForKey(DSUserDefaultsKeyMenuBarIconHighlightDisabled)
        if let button = statusItem.button
        {
            button.target = self;
            button.image = NSImage(named:"ActiveIcon")
            button.action = #selector(AppController.toggleStatus)
            
            //Left click for activate or deactivate the app right click for options
            button.sendActionOn(Int(NSEventMask.LeftMouseUpMask.rawValue)|Int(NSEventMask.RightMouseUpMask.rawValue))
            
            self.setStatusItemActive(false)
        }
    }
    
    
    func configureBatteryStatus()
    {
        
        if(!self.batteryStatus.batteryStatusAvilable)
        {
            return
        }
    
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(AppController.batteryCapacityThresholdDidChange(_:)), name: DSBatteryCapacityThresholdDidChangeNotification, object: nil)
    
        // Start receiving battery status changes
        if(NSUserDefaults.standardUserDefaults().batteryCapacityThresholdEnabled)
        {
            self.batteryStatus.registerForCapacityChangesIfNeeded()
        }
    }
   
// MARK: - Battery Capacity Threshold Changes
    func batteryCapacityThresholdDidChange(notification:NSNotification)
    {
        if(!self.batteryStatus.batteryStatusAvilable)
        {
            return
        }
    
        self.terminateTimer()
    }
    
    func checkAndEnableBatteryOverride()
    {
        let currentCapacity = self.batteryStatus.currentCapacity()
        let threshold = NSUserDefaults.standardUserDefaults().batteryCapacityThreshold
    
        self.batteryOverrideEnabled = currentCapacity <= threshold
    }
    
    func disableBatteryOverride()
    {
        self.batteryOverrideEnabled = false
    }
    
    func batteryCapacityDidChange(capacity:Float)
    {
        let threshold = NSUserDefaults.standardUserDefaults().batteryCapacityThreshold
        
        if(self.sleepWakeTimer.isScheduled() && (capacity <= threshold) && !self.batteryOverrideEnabled)
        {
            self.terminateTimer()
        }
    }
    
    
    func shouldActivateOnLaunch()->Bool
    {
        return NSUserDefaults.standardUserDefaults().activateOnLaunch
    }
    
    
    @IBAction func  toggleActivateOnLaunch(sender:AnyObject)
    {
        let defaults = NSUserDefaults.standardUserDefaults()
        defaults.activateOnLaunch = !defaults.activateOnLaunch
        defaults.synchronize()
    }
    
    
// MARK: - KVO
    override func observeValueForKeyPath(keyPath: String?,
        ofObject object: AnyObject?,
        change: [String : AnyObject]?,
        context: UnsafeMutablePointer<Void>)
    {
        if (object!.isEqual(self.sleepWakeTimer) && keyPath == "scheduled")
        {
            self.setStatusItemActive((change![NSKeyValueChangeNewKey]?.boolValue)!)
        }
    }
    
    
    
    func activateTimerWithTimeInterval(timeInterval:NSTimeInterval)
    {
    // Do not allow negative time intervals
        if(timeInterval < 0)
        {
            return;
        }
    
    // Check battery overrides and register for capacity changes.
    self.checkAndEnableBatteryOverride()
    if(NSUserDefaults.standardUserDefaults().batteryCapacityThresholdEnabled)
    {
        self.batteryStatus.registerForCapacityChangesIfNeeded()
    }

    
        self.sleepWakeTimer.scheduleWithTimeInterval(timeInterval) { (cancelled:Bool) -> Void in
            
        }
 

}
    
  
    
    
    func setStatusItemActive(active:Bool)
    {
        let button = self.statusItem.button;
        let menubarIcon = MenuBarIcon.currentIcon()
        
    
        if(active)
        {
            button!.image = menubarIcon.activeIcon
            button!.toolTip = NSLocalizedString("Click to allow sleep\nRight click to show menu", comment: "")
        }
        else
        {
            button!.image = menubarIcon.inactiveIcon
            button!.toolTip = NSLocalizedString("Click to prevent sleep\nRight click to show menu", comment: "")
        }
    }

    
    func showMenu()
    {
        self.statusItem.popUpStatusItemMenu(self.menu);
    }
    
    
    // Action for status item
    func toggleStatus()
    {
        let event = NSApplication.sharedApplication().currentEvent
        
        if ((event!.modifierFlags.contains(NSEventModifierFlags.ControlKeyMask)) || (event!.type == NSEventType.RightMouseUp))
        {
            self.showMenu();
            
        }
        else if(self.sleepWakeTimer.isScheduled())
        {
            self.terminateTimer()
        }
        else
        {
            self.activateTimer()
        }
        
        
    }
    
    func terminateTimer()->Void
    {
    
        self.disableBatteryOverride()
        self.batteryStatus.unregisterFromCapacityChanges()
        
       if(self.sleepWakeTimer.isScheduled() == true)
       {
            self.sleepWakeTimer.invalidate();
       }
    }
    
    func activateTimer()->Void
    {
        self.activateTimerWithTimeInterval(self.defaultTimeInterval())
    }
    

    
    @IBAction func selectTimeInterval(sender: NSMenuItem)
    {
        self.terminateTimer()
        
        
        if (sender.alternate)
        {
            self.setDefaultTimeInterval(NSTimeInterval(sender.tag))
        }
        else
        {
            
            dispatch_async(dispatch_get_main_queue(), {[weak self] () -> Void in
                
                let seconds = sender.tag
                self!.activateTimerWithTimeInterval(NSTimeInterval(seconds));
                });
        }

    }
    
    
    

    // Update the selected menu item and timer countdown menu item
    func menuNeedsUpdate(menu: NSMenu)
    {
        if(!menu.isEqual(self.timerMenu))
        {
            return;
        }
    
        for item in menu.itemArray
        {
            item.state = NSOffState;
    
            let seconds = NSTimeInterval(item.tag);
            if(seconds > 0)
            {
                if(self.sleepWakeTimer.scheduledTimeInterval == seconds)
                {
                    item.state = NSOnState;
                }
            }
            else if((seconds == 0) && !item.separatorItem)
            {
                item.state = NSOffState;
                if(self.sleepWakeTimer.isScheduled() && (self.sleepWakeTimer.scheduledTimeInterval == SleepWakeTimeIntervalIndefinite))
                {
                    item.state = NSOnState
                }
            }
            else
            {
                // It will display the timer countdown menu item
                item.hidden = true;
                

                if((self.sleepWakeTimer.fireDate) != nil)
                {
                    item.hidden = false
                    
                    let dateFormatter = NSDateComponentsFormatter()
                    dateFormatter.unitsStyle = .Short
                    dateFormatter.allowedUnits = NSCalendarUnit(rawValue: NSCalendarUnit.Second.rawValue | NSCalendarUnit.Minute.rawValue | NSCalendarUnit.Hour.rawValue)
                    
                    dateFormatter.includesTimeRemainingPhrase = true
                
                    item.title = dateFormatter.stringFromDate(NSDate(), toDate: self.sleepWakeTimer.fireDate!)!
                    
                }
            }
        }
    }


   //Default Time Interval......
    func defaultTimeInterval()->NSTimeInterval
    {
       return NSUserDefaults.standardUserDefaults().defaultTimeInterval;

    }
    
    func setDefaultTimeInterval(interval:NSTimeInterval)
    {
        NSUserDefaults.standardUserDefaults().defaultTimeInterval = interval;
    }
    
    
}
