//
//  NSUserDefaults+Keys.swift
//  DontSleep
//
//  Created by avnish kumar on 10/02/16.
//  Copyright © 2016 avnish kumar. All rights reserved.
//

import Foundation

let  DSUserDefaultsKeyActivateOnLaunch = "info.DontSleep.ActivateOnLaunch"
let  DSUserDefaultsKeyNotificationsEnabled = "info.DontSleep.NotificationsEnabled"
let DSUserDefaultsKeyDefaultTimeInterval = "info.DontSleep.TimeInterval"
let DSUserDefaultsKeyAllowDisplaySleep = "info.DontSleep.AllowDisplaySleep"
let DSUserDefaultsKeyMenuBarIconHighlightDisabled = "info.DontSleep.MenuBarIconHighlightDisabled"
let DSUserDefaultsKeyBatteryCapacityThresholdEnabled = "info.DontSleep.BatteryCapacityThresholdEnabled"
let DSUserDefaultsKeyBatteryCapacityThreshold = "info.DontSleep.BatteryCapacityThreshold"
let DSUserDefaultsKeyLaunchAtLogin = "info.DontSleep.LaunchAtLogin"


extension NSUserDefaults
{
    var activateOnLaunch:Bool
    {
        set{

            setBool(newValue, forKey: DSUserDefaultsKeyActivateOnLaunch)
        }
        get{
            
            return boolForKey(DSUserDefaultsKeyActivateOnLaunch)
        }
    }
    
    var defaultTimeInterval:NSTimeInterval
    {
        set{
            
            setInteger(Int(newValue), forKey: DSUserDefaultsKeyDefaultTimeInterval)
        }
        get{
            
            return NSTimeInterval(integerForKey(DSUserDefaultsKeyDefaultTimeInterval))
        }
    }
    
    var notificationsEnabled:Bool
    {
        set{
            
            setBool(newValue, forKey: DSUserDefaultsKeyNotificationsEnabled)
        }
        get{
            return boolForKey(DSUserDefaultsKeyNotificationsEnabled)
        }
    }
    
        var allowDisplaySleep:Bool
        {
            set{
                
                setBool(newValue, forKey: DSUserDefaultsKeyAllowDisplaySleep)
            }
            get{
                
                return boolForKey(DSUserDefaultsKeyAllowDisplaySleep)
            }
        }
    
        var menuBarIconHighlightDisabled:Bool
        {
            set{
                
                setBool(newValue, forKey: DSUserDefaultsKeyMenuBarIconHighlightDisabled)
            }
            get{
                return boolForKey(DSUserDefaultsKeyMenuBarIconHighlightDisabled)
            }
        }
    
        var batteryCapacityThresholdEnabled:Bool
        {
            set{
            
                setBool(newValue, forKey: DSUserDefaultsKeyBatteryCapacityThresholdEnabled)
            }
            get{
            
                return boolForKey(DSUserDefaultsKeyBatteryCapacityThresholdEnabled)

            }
        }
    
        var batteryCapacityThreshold:Float
        {
            set{
            
                setFloat(newValue, forKey: DSUserDefaultsKeyBatteryCapacityThreshold)
            }
            get{
                
                let threshold = floatForKey(DSUserDefaultsKeyBatteryCapacityThreshold)
                return max(threshold, 10.0)

            }
        }
    
}
