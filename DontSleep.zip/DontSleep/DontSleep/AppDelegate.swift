//
//  AppDelegate.swift
//  DontSleep
//
//  Created by avnish kumar on 01/02/16.
//  Copyright © 2016 avnish kumar. All rights reserved.
//

import Cocoa


@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate, NSWindowDelegate
{
    //Preference Window..
    var preferencesWindowController:NSWindowController?
    
    
    func applicationDidFinishLaunching(aNotification: NSNotification)
    {
        
       preferencesWindowController = NSStoryboard(name: "Preferences", bundle: nil).instantiateInitialController() as? NSWindowController
        
       
    }

    
    
    func applicationWillTerminate(aNotification: NSNotification) {
        // Insert code here to tear down your application
    }
    
    
    @IBAction func showPreferencesWindow(sender:AnyObject)
    {
       NSApplication.sharedApplication().activateIgnoringOtherApps(true)
        preferencesWindowController!.showWindow(sender)
        self.preferencesWindowController!.window?.delegate = self
        
        
    }
    
    func windowWillClose(notification: NSNotification) {
        
        
    }
    
    
        
    
}

