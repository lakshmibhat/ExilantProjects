//
//  YesNoListTableViewController.swift
//  TraningApp
//
//  Created by lakshmi r bhat on 16/06/16.
//  Copyright © 2016 basagond a mugganauar. All rights reserved.
//

import UIKit

class YesNoListTableViewController: UITableViewController {
    var yesNo :[YesNo] = []
    var coreData : CoreData?
//    override func viewDidLoad() {
//        super.viewDidLoad()
//
//        // Uncomment the following line to preserve selection between presentations
//        // self.clearsSelectionOnViewWillAppear = false
//
//        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
//        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
//    }
//
//    override func didReceiveMemoryWarning() {
//        super.didReceiveMemoryWarning()
//        // Dispose of any resources that can be recreated.
//    }
//
//    // MARK: - Table view data source
//
//    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
//        // #warning Incomplete implementation, return the number of sections
//        return 1
//    }
//
//    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        // #warning Incomplete implementation, return the number of rows
//        return yesNo.count
//    }
//
//    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
//        let cellIdentifier = "Cell"
//        let cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier, forIndexPath: indexPath)
//        cell.textLabel?.text = yesNo[indexPath.row].queNum! + ". " + yesNo[indexPath.row].question!
//        cell.textLabel?.font = UIFont(name: (cell.textLabel?.font?.fontName)!, size: 18)
//        // Configure the cell...
//        
//        return cell
//    }
    
    let templates = ["1. INT is variable.?", "2. INT can hold numbers.?", "3. IOS uses JAVA.?", "4.Swift is open source.?"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - Table view data source
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return templates.count
    }
    
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let newData = ["Yes", "No", "No","Yes"]
        let cell = tableView.dequeueReusableCellWithIdentifier("Cell", forIndexPath: indexPath)
        
        
        cell.textLabel?.text = templates[indexPath.row]
        let imageFilename = templates[indexPath.row].lowercaseString.stringByReplacingOccurrencesOfString(" ", withString: "_", options: [], range: nil)
        
        
        cell.imageView?.image = UIImage(named: imageFilename)
        cell.separatorInset.left = 20.0
        cell.separatorInset.right = 20.0
        cell.separatorInset.top = 50.0
        cell.separatorInset.bottom = 50.0
        cell.layer.cornerRadius = 20.0
        
        cell.imageView!.clipsToBounds = true;
        cell.imageView!.layer.borderWidth = 2;
        
        cell.imageView!.layer.cornerRadius = 10;
        cell.imageView!.sizeToFit()
        let newLabel1 = UILabel(frame: CGRectMake(200.0, 35, 200.0, 15.0))
        newLabel1.text = newData[indexPath.row]
        newLabel1.tag = 1
        newLabel1.textColor = UIColor.redColor()
        cell.addSubview(newLabel1)
        
        return cell
    }
    
    
    @IBAction func previewAction(sender: UIBarButtonItem) {
        let secondViewController = self.storyboard?.instantiateViewControllerWithIdentifier("Question") as! QuestionsViewController
        self.presentViewController(secondViewController, animated: true, completion: nil)
        
    }
    
    override func tableView(tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        
        let headerView = view as! UITableViewHeaderFooterView
        headerView.textLabel?.textColor = UIColor.orangeColor()
        headerView.textLabel?.font = UIFont(name: "Avenir", size: 25.0)
    }
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let nextViewController = self.storyboard?.instantiateViewControllerWithIdentifier("editYN") as! YesNoPreviewController
        self.presentViewController(nextViewController, animated: true, completion: nil)
    }
    @IBAction func backToListOfFIB(segue:UIStoryboardSegue)
    {
        
    }
 
    @IBAction func backToListYN(segue:UIStoryboardSegue) {
        
    }
    @IBAction func clickToSave(sender: UIBarButtonItem) {
        
        
        let alertView = UIAlertController(title: "Success", message: "Questions submitted successfully.", preferredStyle: .Alert)
        alertView.addAction(UIAlertAction(title: "OK", style: .Default, handler:nil))
        
        presentViewController(alertView, animated: true, completion: nil)
        
    }}
