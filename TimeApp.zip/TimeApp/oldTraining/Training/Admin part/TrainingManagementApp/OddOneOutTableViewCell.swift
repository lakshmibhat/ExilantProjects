//
//  OddOneOutTableViewCell.swift
//  TraningApp
//
//  Created by vedashree k on 24/06/16.
//  Copyright © 2016 basagond a mugganauar. All rights reserved.
//

import UIKit

class OddOneOutTableViewCell: UITableViewCell {
    
    @IBOutlet weak var wordLabel: UILabel!
    @IBOutlet weak var orderLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    


}
