//
//  Assesment.swift
//  TrainingManagementApp
//
//  Created by sowmyashree nanjappa on 21/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import Foundation

class Assesment: NSObject {
    var title:String?
    var date:String?
    var time:String?
    var numberOfQuestion:Int?

    init(title:String,date:String,time:String,numberOfQuestion:Int) {
        self.title = title
        self.date = date
        self.time = time
        self.numberOfQuestion = numberOfQuestion
     
    }
}