//
//  AssesmentTableViewCell.swift
//  TrainingManagementApp
//
//  Created by sowmyashree nanjappa on 20/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class AssesmentTableViewCell: UITableViewCell {

    
    @IBOutlet var assesmentName: UILabel!

    @IBOutlet var numberOfQuestion: UILabel!
    @IBOutlet var date: UILabel!
    @IBOutlet var time: UILabel!
    @IBOutlet var size: UILabel!
      override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
