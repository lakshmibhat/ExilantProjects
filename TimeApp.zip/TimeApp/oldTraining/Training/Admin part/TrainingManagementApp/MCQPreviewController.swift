//
//  MCQPreviewController.swift
//  TraningApp
//
//  Created by lakshmi r bhat on 14/06/16.
//  Copyright © 2016 basagond a mugganauar. All rights reserved.
//

import UIKit

class MCQPreviewController: UIViewController {
    let checkedImage = UIImage(named: "checked.png")! as UIImage
    let uncheckedImage = UIImage(named: "unchecked.png")! as UIImage
    @IBOutlet weak var queNum: UILabel!
    
    @IBOutlet weak var question: UITextView!
    
    @IBOutlet weak var option1: UITextField!
    
    @IBOutlet weak var option2: UITextField!
    
    @IBOutlet weak var option3: UITextField!
    
    @IBOutlet weak var option4: UITextField!
    
    @IBOutlet weak var descrption: UITextField!
    
    
    @IBOutlet weak var button1: UIButton!
    
    @IBOutlet weak var button2: UIButton!
    
    @IBOutlet weak var button3: UIButton!
    
    @IBOutlet weak var button4: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func checkButtonAction(sender: UIButton) {
        if sender.tag == button1.tag{
            button1.setImage(checkedImage, forState: .Normal)
            button2.setImage(uncheckedImage, forState: .Normal)
            button3.setImage(uncheckedImage, forState: .Normal)
            button4.setImage(uncheckedImage, forState: .Normal)
        }
        if sender.tag == button2.tag{
            button2.setImage(checkedImage, forState: .Normal)
            button1.setImage(uncheckedImage, forState: .Normal)
            button3.setImage(uncheckedImage, forState: .Normal)
            button4.setImage(uncheckedImage, forState: .Normal)
        }
        if sender.tag == button3.tag{
            button3.setImage(checkedImage, forState: .Normal)
            button1.setImage(uncheckedImage, forState: .Normal)
            button2.setImage(uncheckedImage, forState: .Normal)
            button4.setImage(uncheckedImage, forState: .Normal)
        }
        if sender.tag == button4.tag{
            button4.setImage(checkedImage, forState: .Normal)
            button2.setImage(uncheckedImage, forState: .Normal)
            button3.setImage(uncheckedImage, forState: .Normal)
            button1.setImage(uncheckedImage, forState: .Normal)
        }

    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
