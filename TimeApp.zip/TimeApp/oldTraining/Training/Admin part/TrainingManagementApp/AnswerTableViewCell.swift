//
//  AnswerTableViewCell.swift
//  TrainingManagementApp
//
//  Created by sowmyashree nanjappa on 14/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class AnswerTableViewCell: UITableViewCell {

    @IBOutlet var time: UILabel!
    @IBOutlet var date: UILabel!
    @IBOutlet var answerdBy: UILabel!
 
    @IBOutlet var AnswerdStack: UIStackView!
    @IBOutlet var answer: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
