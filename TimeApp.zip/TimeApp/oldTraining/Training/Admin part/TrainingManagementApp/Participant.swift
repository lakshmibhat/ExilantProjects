//
//  Participant.swift
//  TrainingManagementApp
//
//  Created by sowmyashree nanjappa on 21/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import Foundation

class Participant: NSObject {
   let name:String?
   let role:String?
    var mailId:String?
    var image:String?
    init(name:String,role:String,mailId:String,image:String) {
        self.name = name
        self.role = role
        self.mailId = mailId
        self.image = image
    }
}