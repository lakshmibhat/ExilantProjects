//
//  mtfPopoverController.swift
//  TraningApp
//
//  Created by basagond a mugganauar on 13/06/16.
//  Copyright © 2016 basagond a mugganauar. All rights reserved.
//

import UIKit

class mtfPopoverController: UIViewController, UIPopoverControllerDelegate {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}
