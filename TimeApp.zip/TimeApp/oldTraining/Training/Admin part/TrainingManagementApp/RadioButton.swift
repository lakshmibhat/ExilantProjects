//
//  RadioButton.swift
//  TraningApp
//
//  Created by vedashree k on 16/06/16.
//  Copyright © 2016 basagond a mugganauar. All rights reserved.
//

import UIKit

class RadioButton: UIButton {
    let checkedImage = UIImage(named: "checkedRadio")! as UIImage
    let uncheckedImage = UIImage(named: "uncheckedRadio")! as UIImage
    
    // Bool property
    var isChecked: Bool = false {
        didSet{
            if isChecked == true {
                self.setImage(checkedImage, forState: .Normal)
            } else {
                self.setImage(uncheckedImage, forState: .Normal)
            }
        }
    }
    
    override func awakeFromNib() {
        self.isChecked = false
    }

    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */

}
