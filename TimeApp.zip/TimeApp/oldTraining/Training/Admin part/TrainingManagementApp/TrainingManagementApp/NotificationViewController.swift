//
//  NotificationViewController.swift
//  TrainingManagementApp
//
//  Created by manohara reddy p on 13/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class NotificationViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var notificationTable: UITableView!
    
    
    var notificationArray = [Notification(groupName:"Java",type:NotificationType.DocumentShare,setFavourite:false,sender:"by Sowmya",description:"Oops concept 2nd chapter"),Notification(groupName:"cocoa",type:NotificationType.RequestToJoin,setFavourite:false,sender:"by Basu",description:"Requesting to join for cocoa training on 12-5-2015"),Notification(groupName:"Swift",type:NotificationType.ScheduleForSession,setFavourite:true,sender:"by Satyam",description:"Class by sowmya on 12-08-2015 at 12:30 PM")]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        notificationTable.dataSource = self
        notificationTable.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
  
    func configureCell(cell:NotificationCell,row:Int) -> NotificationCell
    {
        
        cell.groupName.text = notificationArray[row].groupName
        cell.sender.text = notificationArray[row].sender
        cell.settingFeverate.tag = row
        if notificationArray[row].setFavourite {
            cell.settingFeverate.backgroundColor = UIColor.greenColor()
            
        } else{
            cell.settingFeverate.backgroundColor = UIColor.whiteColor()
        }
        
        switch  notificationArray[row].type{
        case NotificationType.DocumentShare:
            cell.TypeOfMessage.image = UIImage(named:"Documents")
        case NotificationType.RequestToJoin:
            cell.TypeOfMessage.image = UIImage(named:"AddUser")
        case NotificationType.ScheduleForSession:
            cell.TypeOfMessage.image = UIImage(named:"Schedule")
            
        }
        cell.descriptionMessage.text = notificationArray[row].description
        
        return cell
    }
    
    
    @IBAction func settingFavourite(sender: UIButton) {
        
        let selected = notificationArray[sender.tag]
        if selected.setFavourite
        {
           selected.setFavourite = false
        } else
        {
            selected.setFavourite = true
        }
        notificationTable.reloadData()
        
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
extension NotificationViewController
{
     func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
     {
        return notificationArray.count
     }
    
  
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCellWithIdentifier("Schedule") as! NotificationCell
        return configureCell(cell,row: indexPath.row)
    }
    
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        let fileType = notificationArray[indexPath.row].type
        let selectedCell = tableView.cellForRowAtIndexPath(indexPath) as UITableViewCell!
        
        for subViews in selectedCell.contentView.subviews {
            
              for subview in subViews.subviews
                {
                    if subview is UIButton {
                        
                        if notificationArray[indexPath.row].setFavourite {
                            
                            subview.backgroundColor = UIColor.greenColor()
                            
                        } else {
                            
                            subview.backgroundColor = UIColor.whiteColor()
                        }
                    }
                }
           }
        
        navigationItem.backBarButtonItem  = UIBarButtonItem(title:"Notification", style: .Plain, target: nil, action: nil)
        performSegueWithIdentifier("\(fileType)", sender: self)
    }
  
}
