//
//  YesNo.swift
//  TraningApp
//
//  Created by lakshmi r bhat on 16/06/16.
//  Copyright © 2016 basagond a mugganauar. All rights reserved.
//

import Foundation
import CoreData


class YesNo: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
