//
//  YesNoPreviewController.swift
//  TraningApp
//
//  Created by lakshmi r bhat on 16/06/16.
//  Copyright © 2016 basagond a mugganauar. All rights reserved.
//

import UIKit

class YesNoPreviewController: UIViewController {
    let checkedRadioImage = UIImage(named: "checkedRadio.png")! as UIImage
    let uncheckedRadioImage = UIImage(named: "uncheckedRadio.png")! as UIImage
    @IBOutlet weak var queNumber: UILabel!
    
    @IBOutlet weak var question: UITextView!
    
    @IBOutlet weak var trueButton: UIButton!
    
    @IBOutlet weak var falseButton: UIButton!
    
    @IBOutlet weak var descrption: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func TrueFalseAction(sender: UIButton) {
        if sender.tag == trueButton.tag{
            trueButton.setImage(checkedRadioImage, forState: .Normal)
            falseButton.setImage(uncheckedRadioImage, forState: .Normal)
        }
        if sender.tag == falseButton.tag {
            falseButton.setImage(checkedRadioImage, forState: .Normal)
            trueButton.setImage(uncheckedRadioImage, forState: .Normal)
            
        }

    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
