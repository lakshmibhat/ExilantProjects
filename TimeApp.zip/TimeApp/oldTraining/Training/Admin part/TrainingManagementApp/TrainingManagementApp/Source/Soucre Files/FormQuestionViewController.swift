//
//  FormQuestionViewController.swift
//  TraningApp
//
//  Created by swathi m on 6/23/16.
//  Copyright © 2016 basagond a mugganauar. All rights reserved.
//

import UIKit

class FormQuestionViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func clickToSave(sender: UIBarButtonItem) {
        
        
        let alertView = UIAlertController(title: "Success", message: "Questions submitted successfully.", preferredStyle: .Alert)
        
        
        alertView.addAction(UIAlertAction(title: "OK", style: .Default, handler:nil))
        presentViewController(alertView, animated: true, completion: nil)
        
    }
    @IBAction func backToFQ(segue:UIStoryboardSegue)
    {
        
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
