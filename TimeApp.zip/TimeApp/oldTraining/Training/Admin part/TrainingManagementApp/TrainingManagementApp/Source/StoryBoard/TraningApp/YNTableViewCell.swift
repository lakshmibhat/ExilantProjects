//
//  YNTableViewCell.swift
//  TraningApp
//
//  Created by vedashree k on 16/06/16.
//  Copyright © 2016 basagond a mugganauar. All rights reserved.
//

import UIKit

class YNTableViewCell: UITableViewCell {

    @IBOutlet var radioButton: [RadioButton]!
    
    @IBOutlet var options: [UILabel]!
    @IBOutlet weak var YNQuestion: UILabel!
    @IBOutlet weak var YNQuestionNumber: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    @IBAction func selectAnswer(sender: UIButton) {
        for button in radioButton{
            if button != sender{
                if button.isChecked == true{
                    button.isChecked = false
                }
            }
            else{
                button.isChecked = !(button.isChecked)
            }
        }
    }
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }

}
