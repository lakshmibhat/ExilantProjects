//
//  mcqViewController.swift
//  TraningApp
//
//  Created by basagond a mugganauar on 09/06/16.
//  Copyright © 2016 basagond a mugganauar. All rights reserved.
//

import UIKit

class mcqViewController: UIViewController {
    let checkedImage = UIImage(named: "checked.png")! as UIImage
    let uncheckedImage = UIImage(named: "unchecked.png")! as UIImage
    var isChecked: Bool = false
    var placeholderLabel:UILabel!
    var coreData:CoreData?
    var answer:String!
    var count = 0
    var MCQList :MCQListTableViewController?
    var question : String = ""
    var options = [String](count:4, repeatedValue: "")
    var qNum : String = ""
    @IBOutlet weak var textView: UITextView!
    
    @IBOutlet weak var button1: CheckBox!
    
    @IBOutlet weak var button2: CheckBox!
    
    @IBOutlet weak var button3: CheckBox!
    
    @IBOutlet weak var button4: CheckBox!
    @IBOutlet var checkBoxBtns: [CheckBox]!
    @IBOutlet var optionsLabel: [UITextField]!
    
    @IBOutlet weak var option1: UITextField!
    
    @IBOutlet weak var option2: UITextField!
    
    @IBOutlet weak var option3: UITextField!
    
    @IBOutlet weak var option4: UITextField!
    
    
    @IBOutlet weak var descrption: UITextView!
    @IBOutlet weak var nextBTN: UIButton!
    
    @IBOutlet weak var queNumber: UILabel!
    
    @IBOutlet weak var warningLabel: UILabel!
    
    @IBOutlet weak var nextButton: UIButton!


    override func viewDidLoad() {
        super.viewDidLoad()
        coreData=CoreData()
        reloadView()
       
        if question != ""{
            nextBTN.setTitle("save", forState: .Normal)
            textView.text = question
            checkBoxBtns.removeAll()
            optionsLabel.removeAll()
            
            option1.text = options[0]
            option2.text = options[1]
            option3.text = options[2]
            option4.text = options[3]
            queNumber.text = qNum
            optionsLabel.append(option1)
            optionsLabel.append(option2)
            optionsLabel.append(option3)
            optionsLabel.append(option4)
            
            checkBoxBtns.append(button1)
            checkBoxBtns.append(button2)
            checkBoxBtns.append(button3)
            checkBoxBtns.append(button4)
            
            for i in 0..<optionsLabel.count{
                if answer == optionsLabel[i].text{
                    (checkBoxBtns[i] ).isChecked = true
                }
            }
            
        }
        else{
            count = coreData!.fetch(String(FillInTheBlanks)).count + coreData!.fetch(String(YesNo)).count + coreData!.fetch(String(MCQ)).count + 1
            queNumber.text = String(count)
        }
        // Do any additional setup after loading the view.
    }
        // Do any additional setup after loading the view.
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
@IBAction func selectAnswer(sender: CheckBox) {
    for button in checkBoxBtns{
        if button != sender{
            if button.isChecked == true{
                button.isChecked = false
            }
        }
        else{
            button.isChecked = !(button.isChecked)
        }
    }
    
}


        func reloadView()
    {
        warningLabel.text = nil
//        textView.delegate = self
        textView.text = nil
        //        placeholderLabel = UILabel()
        //        placeholderLabel.text = "Enter Question Here"
        //        placeholderLabel.font = UIFont.italicSystemFontOfSize(textView.font!.pointSize)
        //        placeholderLabel.sizeToFit()
        //        textView.addSubview(placeholderLabel)
        //        placeholderLabel.frame.origin = CGPointMake(5, textView.font!.pointSize / 2)
        //        placeholderLabel.textColor = UIColor(white: 0, alpha: 0.3)
        //        placeholderLabel.hidden = !textView.text.isEmpty
        option1.text = nil
        option2.text = nil
        option3.text = nil
        option4.text = nil
        descrption.text = nil
        button1.setImage(uncheckedImage, forState: .Normal)
        button2.setImage(uncheckedImage, forState: .Normal)
        button3.setImage(uncheckedImage, forState: .Normal)
        button4.setImage(uncheckedImage, forState: .Normal)
        
        queNumber.text = String(count)
    }
    @IBAction func nextButton(sender: UIButton) {
        if sender.titleLabel!.text != "save"{
            for i in 0..<checkBoxBtns.count{
                if checkBoxBtns[i].currentImage == UIImage(named: "checked")! as UIImage{
                    answer = optionsLabel[i].text
                }
            }
            
            if textView.text.isEmpty {
                textView.subviews[0].hidden = false
            }
            else{
                textView.subviews[0].hidden = true
            }
            if answer == nil {
                warningLabel.text = "Check the correct answer"
                warningLabel.textColor = UIColor.redColor()
                let alertController = UIAlertController(title: "Alert", message:
                    "Check correct answer", preferredStyle: UIAlertControllerStyle.Alert)
                alertController.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default,
                    handler: nil))
                self.presentViewController(alertController, animated: true, completion: nil)
            }
            else{
                if textView.subviews[0].hidden == false || option1.text == "" || option2.text == "" || option3.text == "" || option4.text == ""{
                    let alertController = UIAlertController(title: "Alert", message:
                        "Enter Question and options properly", preferredStyle: UIAlertControllerStyle.Alert)
                    alertController.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default,
                        handler: nil))
                    self.presentViewController(alertController, animated: true, completion: nil)
                }
                else{
                    
                    
                    coreData?.insert(textView.text, option1: option1.text!, option2: option2.text!, option3: option3.text!, option4: option4.text!, description: descrption.text! , answer: answer, noOfQue: queNumber.text!)
                    count = coreData!.fetch(String(FillInTheBlanks)).count + coreData!.fetch(String(YesNo)).count + coreData!.fetch(String(MCQ)).count + 1
                    reloadView()
                    
                }
            }
        }
        else{
            if textView.subviews[0].hidden != false || option1.text != "" || option2.text != "" || option3.text != "" || option4.text != ""{
                let mcq = coreData?.createInstanceOfEntity(String(MCQ),qNum: qNum)
                (mcq as! MCQ).question = textView.text
                (mcq as! MCQ).option1 = option1.text
                (mcq as! MCQ).option2 = option2.text
                (mcq as! MCQ).option3 = option3.text
                (mcq as! MCQ).option4 = option4.text
                
                for i in 0..<checkBoxBtns.count{
                    if checkBoxBtns[i].currentImage == UIImage(named: "checked")! as UIImage{
                        (mcq as! MCQ).answer = optionsLabel[i].text
                    }
                }
                
                
                (mcq as! MCQ).descrption = descrption.text
                (mcq as! MCQ).noOfQue = qNum
                
               
                
                coreData?.update(mcq!,entityName: String(MCQ))
            }
        }

    }
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "PreviewSegue" {
            let destinationController = segue.destinationViewController as! MCQListTableViewController
            coreData?.fetchMCQList()
            destinationController.multiples = (coreData?.MCQArray)!
        }
    }

    @IBAction func resetAction(sender: UIButton) {
        warningLabel.text = nil
        textView.text = nil
      
        option1.text = nil
        option2.text = nil
        option3.text = nil
        option4.text = nil
        descrption.text = nil
        button1.setImage(uncheckedImage, forState: .Normal)
        button2.setImage(uncheckedImage, forState: .Normal)
        button3.setImage(uncheckedImage, forState: .Normal)
        button4.setImage(uncheckedImage, forState: .Normal)
    }
    
    @IBAction func clickToSaveAll(sender: UIBarButtonItem)
    {
        let nextViewController = self.storyboard?.instantiateViewControllerWithIdentifier("listOfMCQ") as! MCQListTableViewController
        self.presentViewController(nextViewController, animated: true, completion: nil)
    }
    
    @IBAction func backToMCQ(segue:UIStoryboardSegue)
    {
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
 

}
