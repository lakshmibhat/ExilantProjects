//
//  MyDocsViewController.swift
//  TrainingManagementApp
//
//  Created by manohara reddy p on 16/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class MyDocsViewController: UIViewController {
    
    
    @IBOutlet weak var docArray: UITableView!
    let docAry = [Document(docTypeImage:DocType.Pdf,docName:"JavaNotes.pdf",docSentDate:"12-9-2015",docSize:"20 MB",fromGrout:"Java",setFavourite:true),Document(docTypeImage:DocType.Pdf,docName:"SwiftBook.pdf",docSentDate:"13-9-2015",docSize:"10 MB",fromGrout:"Swift",setFavourite:false),Document(docTypeImage:DocType.Image,docName:"JavaWorkFlow.png",docSentDate:"13-9-2015",docSize:"2 MB",fromGrout:"Java",setFavourite:true),Document(docTypeImage:DocType.Image,docName:"Swift WorkFlow.png",docSentDate:"15-9-2015",docSize:"3 MB",fromGrout:"Java",setFavourite:true),Document(docTypeImage:DocType.Pdf,docName:"JavaNotes.pdf",docSentDate:"16-9-2015",docSize:"20 MB",fromGrout:"Java",setFavourite:true)]
   

    override func viewDidLoad() {
        super.viewDidLoad()
       docArray.delegate = self
       docArray.dataSource = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
      
    }
    
    @IBAction func setFevouriteChanged(sender: UIButton) {
   
      if  docAry[sender.tag].setFavourite {
        docAry[sender.tag].setFavourite = false
        } else
      {
        docAry[sender.tag].setFavourite = true
      }
        docArray.reloadData()
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}


extension MyDocsViewController:UITableViewDelegate,UITableViewDataSource
{
    
   func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
   {
    
    return docAry.count
    
   }
   
    
 func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
  {
    let cell = tableView.dequeueReusableCellWithIdentifier("DocCell") as! MyDocsTableViewCell
    if docAry[indexPath.row].docTypeImage == DocType.Image {
       cell.docImage.image = UIImage(named: "Image")
    } else {
        cell.docImage.image = UIImage(named: "PDF-1")
    }
    
    cell.docName.text = docAry[indexPath.row].docName
    cell.docSize.text = docAry[indexPath.row].docSize
    cell.docSharedGroupName.text = docAry[indexPath.row].fromGrout
    cell.docSharedDate.text = docAry[indexPath.row].docSentDate
    cell.setFavourite.tag = indexPath.row
    if docAry[indexPath.row].setFavourite
    {
      cell.setFavourite.backgroundColor = UIColor.greenColor()
    } else {
      cell.setFavourite.backgroundColor = UIColor.clearColor()
    }
    
    return cell
  }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
         let cell =  tableView.cellForRowAtIndexPath(indexPath)! as UITableViewCell
        
       for stackView in cell.contentView.subviews
       {
        
        for subview in stackView.subviews
        {
           if subview  is UIButton
           {
            subview.backgroundColor = docAry[indexPath.row].setFavourite ? UIColor.greenColor() :UIColor.clearColor()
           }
        }
    
       }
    }
    
    
    
}
