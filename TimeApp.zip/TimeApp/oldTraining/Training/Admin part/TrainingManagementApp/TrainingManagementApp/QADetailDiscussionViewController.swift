//
//  QADetailDiscussionViewController.swift
//  TrainingManagementApp
//
//  Created by sowmyashree nanjappa on 22/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class QADetailDiscussionViewController: UIViewController ,UITextViewDelegate ,UITableViewDelegate,UITableViewDataSource {
    
    var answerList = ["sequential circuit output depends on current inputs and also past output which is stored as memory","Examples of sequential circuit is AND,OR etc and combinational is like latches,flipflops","In digital circuit theory, sequential logic is a type of logic circuit whose output depends not only on the present value of its input signals but on the sequence of past inputs, the input history.[1][2][3][4] This is in contrast to combinational logic, whose output is a function of only the present input. That is, sequential logic has state (memory) while combinational logic does not. Or, in other words, sequential logic is combinational logic with memory"," difference exists","sequential circuit output depends on current inputs and also past output which is stored as memory","Examples of sequential circuit is AND,OR etc and combinational is like latches,flipflops","In digital circuit theory, sequential logic is a type of logic circuit whose output depends not only on the present value of its input signals but on the sequence of past inputs, the input history.[1][2][3][4] This is in contrast to combinational logic, whose output is a function of only the present input. That is, sequential logic has state (memory) while combinational logic does not. Or, in other words, sequential logic is combinational logic with memory"," difference exists"]
    var originalContentInset:UIEdgeInsets?
    var originalScrollIndicatorInsets:UIEdgeInsets?
    var flag = 1
    @IBOutlet var tableView: UITableView!
    var keyboardFlag = 1
    @IBOutlet var postView: UIView!
    @IBOutlet var postButton: UIButton!
    @IBOutlet var postAnswer: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()
        postAnswer.delegate = self
        postAnswer.textColor = UIColor.grayColor()
        postAnswer.layer.borderColor = UIColor.blueColor().CGColor
        postAnswer.layer.borderWidth = 2.0
        postButton.userInteractionEnabled = false
        
        tableView.dataSource = self
        tableView.delegate = self
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(QADetailDiscussionViewController.keyboardWillShow(_:)), name:UIKeyboardWillShowNotification, object: nil);
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(QADetailDiscussionViewController.keyboardWillHide(_:)), name:UIKeyboardWillHideNotification, object: nil);
        let dismissKeyboard: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(QADetailDiscussionViewController.DisableKeyboard))
        view.addGestureRecognizer(dismissKeyboard)
        //  tableView.tableFooterView = postView
    }
    func DisableKeyboard(){
        
        view.endEditing(true)
    }
    deinit
    {
        NSNotificationCenter.defaultCenter().removeObserver(self, name: UIKeyboardWillShowNotification, object: nil)
        
        NSNotificationCenter.defaultCenter().removeObserver(self, name: UIKeyboardWillHideNotification, object: nil)
    }
    
    func keyboardWillShow(notification: NSNotification) {
        
        var info = notification.userInfo!
        let keyboardFrame: CGRect = (info[UIKeyboardFrameEndUserInfoKey] as! NSValue).CGRectValue()
        
        let keyBoardSize = keyboardFrame.size
        self.view.frame.origin.y = self.view.frame.origin.y - keyBoardSize.height
    }
    
    
    func keyboardWillHide(notification: NSNotification) {
        
        var info = notification.userInfo!
        let keyboardFrame: CGRect = (info[UIKeyboardFrameEndUserInfoKey] as! NSValue).CGRectValue()
        
        let keyBoardSize = keyboardFrame.size
         self.view.frame.origin.y = self.view.frame.origin.y + keyBoardSize.height
    }
    
    
    override func viewWillAppear(animated: Bool) {
        tableView.estimatedRowHeight = 60
        tableView.rowHeight = UITableViewAutomaticDimension
        tableView.scrollRectToVisible(postView.frame, animated: true)
    }
    
    @IBAction func postButton(sender: UIButton) {
        
        if postAnswer.text != " " && postAnswer.text.isEmpty != true && flag == 0
        {
            answerList.append(postAnswer.text)
            
            tableView.reloadData()
            
        }
        
        postAnswer.text = ""
        postAnswer.textColor = UIColor.grayColor()
        self.DisableKeyboard()
        
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func textViewDidBeginEditing(textView: UITextView)
    {   flag = 0
        postButton.userInteractionEnabled = true
        textView.text = ""
        textView.textColor = UIColor.blackColor()
        
    }
    
    
    
    
       func setPostViewHeight()
    {
        var textFrame = postAnswer.frame
        textFrame.size.height = postAnswer.contentSize.height
        postAnswer.frame = textFrame
        
    }
}
extension QADetailDiscussionViewController
{
     func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 2
    }
    
     func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        if section == 0
        {
            return 1
        }
        else
        {
            return answerList.count
        }
    }
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        if indexPath.section == 0
        {
            let cell = tableView.dequeueReusableCellWithIdentifier("QuestionCell", forIndexPath: indexPath) as! QuestionTableViewCell
            cell.question.text = "What is the difference between the sequential and combinational circuits? and expanin in detail the differences with correct examples?"
            cell.askedBy.text = "By: sowmya"
            cell.date.text = "12-02-2015"
            cell.time.text = "12:20 PM"
            // cell.editing = false
            
            return cell
        }
        else
        {
            let cell = tableView.dequeueReusableCellWithIdentifier("AnswerCell", forIndexPath: indexPath) as! AnswerTableViewCell
            cell.answer.text = answerList[indexPath.row]
            cell.answerdBy.text = "By: kanda"
            cell.date.text = "12-2-2015"
            cell.time.text = "1:20 PM"
            //cell.answer.endEditing(true)
            return cell
            
        }
        
        
    }
    
    
}
