//
//  DocumentTableViewCell.swift
//  TrainingManagementApp
//
//  Created by medidi vv satyanarayana murty on 21/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class DocumentTableViewCell: UITableViewCell {

    @IBOutlet var docName: UILabel!
    @IBOutlet var docType: UILabel!
    @IBOutlet var docSize: UILabel!
    @IBOutlet var docImage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
