//
//  DocumentData.swift
//  TrainingManagementApp
//
//  Created by medidi vv satyanarayana murty on 23/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import Foundation
class DocumentData
{
    let genealNameT:String
    let genealTypeT:String
    let genealSizeT:String
    let generalImage:DocImage
    init(genealNameT:String,genealTypeT:String,genealSizeT:String,generalImage:DocImage)
    {
        self.genealNameT = genealNameT
        self.genealTypeT = genealTypeT
        self.genealSizeT = genealSizeT
        self.generalImage = generalImage
    }
    
    enum DocImage
    {
        case Pdf
        case Image
    }
}