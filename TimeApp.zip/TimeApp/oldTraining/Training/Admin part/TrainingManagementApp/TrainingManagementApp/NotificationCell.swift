//
//  SchedulingTimeCell.swift
//  TrainingManagementApp
//
//  Created by manohara reddy p on 13/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class NotificationCell: UITableViewCell {

    @IBOutlet weak var groupName: UILabel!
    @IBOutlet weak var sender: UILabel!
    @IBOutlet weak var TypeOfMessage: UIImageView!
    @IBOutlet weak var settingFeverate: UIButton!
    @IBOutlet weak var descriptionMessage: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        settingFeverate.layer.borderColor = UIColor.blackColor().CGColor

    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }

}
