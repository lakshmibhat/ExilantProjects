//
//  ParticipantStudentTableViewCell.swift
//  TrainingManagementApp
//
//  Created by manohara reddy p on 22/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class ParticipantStudentTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var participantImage: UIImageView!
    
    @IBOutlet weak var name: UILabel!
    
    @IBOutlet weak var designation: UILabel!
    
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
