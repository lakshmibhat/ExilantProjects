//
//  Session.swift
//  TrainingManagementApp
//
//  Created by sowmyashree nanjappa on 23/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class Session: NSObject {
    let session:String!
    let date:String!
    let place:String!
    let time:String!
    init(session:String,date:String,place:String,time:String) {
        self.session = session
        self.date = date
        self.place = place
        self.time = time
    }

}
