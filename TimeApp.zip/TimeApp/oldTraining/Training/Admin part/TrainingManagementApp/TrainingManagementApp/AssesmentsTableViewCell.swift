//
//  AssesmentsTableViewCell.swift
//  TrainingManagementApp
//
//  Created by sowmyashree nanjappa on 20/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class AssesmentsTableViewCell: UITableViewCell {

    @IBOutlet var assesmentName: UILabel!

    @IBOutlet var numberOfQuestions: UILabel!
   
    @IBOutlet var date: UILabel!
    @IBOutlet var time: UILabel!
  

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
