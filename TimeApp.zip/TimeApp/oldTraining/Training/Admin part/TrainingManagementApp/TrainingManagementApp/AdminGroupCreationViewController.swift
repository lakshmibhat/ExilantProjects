//
//  GroupCreationViewController.swift
//  TrainingManagementApp
//
//  Created by medidi vv satyanarayana murty on 24/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class AdminGroupCreationViewController: UIViewController
{
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }
}
