//
//  AddMaterialTableViewCell.swift
//  TrainingManagementApp
//
//  Created by sowmyashree nanjappa on 23/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class AddMaterialTableViewCell: UITableViewCell {
    var postObj :Material?
    @IBOutlet var fileLocation: UITextField!
    @IBOutlet var fileDescription: UITextField!
    @IBOutlet var fileName: UITextField!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    @IBAction func uploadButton(sender: UIButton) {
        
        postObj = Material(title: fileName.text!, by: "sowmya", date: "12-2-2015", size: "10 kb", image: "PDF")
        
    }
}
