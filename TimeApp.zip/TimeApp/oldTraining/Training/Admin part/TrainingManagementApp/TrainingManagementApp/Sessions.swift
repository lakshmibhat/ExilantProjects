//
//  Sessions.swift
//  TrainingManagementApp
//
//  Created by medidi vv satyanarayana murty on 27/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import Foundation
class SessionsNumbers
{
    let sessionNumber:String
    let sessiontime:String
   
    
    init (sessionNumber:String,sessiontime:String)
    {
        self.sessionNumber = sessionNumber
        self.sessiontime  = sessiontime
       
    }
    
}