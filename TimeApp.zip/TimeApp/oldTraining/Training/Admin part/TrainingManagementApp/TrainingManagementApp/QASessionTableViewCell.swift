//
//  QASessionTableViewCell.swift
//  TrainingManagementApp
//
//  Created by manohara reddy p on 22/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class QASessionTableViewCell: UITableViewCell {

    @IBOutlet weak var viewAnswers: UIButton!
    @IBOutlet weak var quectionAskedDate: UILabel!
    @IBOutlet weak var sender: UILabel!
    @IBOutlet weak var question: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
