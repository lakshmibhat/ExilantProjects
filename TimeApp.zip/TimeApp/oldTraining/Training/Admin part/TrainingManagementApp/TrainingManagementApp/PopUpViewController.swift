//
//  PopUpViewController.swift
//  TrainingManagementApp
//
//  Created by manohara reddy p on 17/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit



protocol Selected {
    func value(selected:Int)
}
class PopUpViewController: UIViewController {

    var selected:Selected?
    @IBAction func popOverSelected(sender: UIButton) {
        if let selected = selected
        {
          selected.value(sender.tag)
        }
        dismiss()
    }
   
   
    func dismiss() {
    self.dismissViewControllerAnimated(true, completion: nil)
    }
}
