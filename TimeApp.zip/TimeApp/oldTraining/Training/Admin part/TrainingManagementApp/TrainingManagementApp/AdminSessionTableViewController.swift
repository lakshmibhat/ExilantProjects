//
//  AdminSessionTableViewController.swift
//  TrainingManagementApp
//
//  Created by medidi vv satyanarayana murty on 27/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class AdminSessionTableViewController: UITableViewController
{

   // var sessionsnumber =  Data.sessions
    var session = ["Session-1"]
    var SessionTime = ["9Am-11Am"]
    var id = [String]()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
       
       id = ["A","B","C"]
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
       
    }

    // MARK: - Table view data source

//    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
//        // #warning Incomplete implementation, return the number of sections
//        return sessions.count
//    }
//
//    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        // #warning Incomplete implementation, return the number of rows
//        return 0
//    }

    
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return session.count
    }

    
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath)
    {
        let vcName = id[indexPath.row]
        let viewController = storyboard?.instantiateViewControllerWithIdentifier(vcName)
        self.navigationController?.pushViewController(viewController!, animated: true)
    }

 


    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCellWithIdentifier("AdminSessionCell", forIndexPath: indexPath) as! TrainersTableViewCell
        
        cell.sessionNumber?.text = session[indexPath.row]
        cell.sessionNumber.textColor = UIColor.blueColor()
        
        cell.sessionTime.text = SessionTime[indexPath.row]
        cell.sessionTime.textColor = UIColor.redColor()
        
        cell.sessionCource.hidden = true
        cell.sessionTrainer.hidden = true
        
        
        return cell
      
    }
 
    @IBAction func createSession(sender: AnyObject)
    {
        let alert = UIAlertController(title: "New Group Name",
                                      message: "Add a new group Details",
                                      preferredStyle: .Alert)
        
        let saveAction = UIAlertAction(title: "Save",
                                       style: .Default,
                                       handler: { (action:UIAlertAction) -> Void in
                                        
                                        let textField = alert.textFields!.first
                                        self.session.append(textField!.text!)
                                        
                                        let textField1 = alert.textFields!.first
                                        self.SessionTime.append(textField1!.text!)
                                        
                                        
                                        self.tableView.reloadData()
                                   
        })
        
        
        
        let cancelAction = UIAlertAction(title: "Cancel",
                                         style: .Default) { (action: UIAlertAction) -> Void in
        }
        
        alert.addTextFieldWithConfigurationHandler
            {
                (textField: UITextField) -> Void in
                textField.placeholder = "Session Type"
                
        }
        alert.addTextFieldWithConfigurationHandler
            {
                (textField1: UITextField) -> Void in
                textField1.placeholder = "Session Time"
                
        }
        
        
        
        alert.addAction(saveAction)
        alert.addAction(cancelAction)
        
        presentViewController(alert,
                              animated: true,
                              completion: nil)
        
        

        
    }

    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
