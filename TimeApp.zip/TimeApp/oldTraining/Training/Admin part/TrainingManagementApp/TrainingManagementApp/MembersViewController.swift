//
//  MainViewController.swift
//  TrainingManagementApp
//
//  Created by medidi vv satyanarayana murty on 14/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class MembersViewController:  UIViewController, UITableViewDataSource,UITableViewDelegate
{
    @IBOutlet var segmentedControl: UISegmentedControl!
    var group = [String]()
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        group = ["Trainer1", "Trainer2"]
        
       
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    @IBAction func segmentedControlStateChanged(sender: AnyObject)
    {
        switch segmentedControl.selectedSegmentIndex
        {
        case 0:
            print("Trainers You Seleted")
           
            
        case 1:
            print("Students You Seleted")
           
            
        default:
            print("Trainers You Seleted")
        }
    }
  func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       
        return group.count
    }
    
    
   func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("member", forIndexPath: indexPath)
        
 
        
        cell.textLabel!.text = group[indexPath.row]
        
        return cell
    }
    

}
