//
//  DocArrayTableViewCell.swift
//  TrainingManagementApp
//
//  Created by manohara reddy p on 22/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class DocArrayTableViewCell: UITableViewCell {

    @IBOutlet weak var docImage: UIImageView!
    
    @IBOutlet weak var docName: UILabel!
    
    @IBOutlet weak var docSize: UILabel!
    @IBOutlet weak var docSender: UILabel!
    @IBOutlet weak var sharedDate: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
