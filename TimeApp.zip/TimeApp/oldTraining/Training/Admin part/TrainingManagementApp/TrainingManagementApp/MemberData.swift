//
//  MemberData.swift
//  TrainingManagementApp
//
//  Created by medidi vv satyanarayana murty on 23/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import Foundation
class MemberData
{
    let generalName:String
    let generalType:String
    let generalimage:String
    init (generalName:String,generalType:String,generalimage:String)
    {
        self.generalName = generalName
        self.generalType = generalType
        self.generalimage = generalimage
    }
}