//
//  StudentParticipant.swift
//  TrainingManagementApp
//
//  Created by manohara reddy p on 22/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import Foundation

class StudentParticipant {
  
    let name:String
    let designation:String
    let image:String
    init(name:String,designation:String,image:String)
    {
        self.name =  name
        self.designation = designation
        self.image = image
    }
}