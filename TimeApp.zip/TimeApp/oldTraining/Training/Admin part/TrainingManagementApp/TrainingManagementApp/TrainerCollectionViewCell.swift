//
//  TrainerCollectionViewCell.swift
//  TrainingManagementApp
//
//  Created by manohara reddy p on 15/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class TrainerCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var trainerImage: UIImageView!
    @IBOutlet weak var trainerName: UILabel!
    @IBOutlet weak var trainerEmailId: UILabel!
}
