//
//  Document.swift
//  TrainingManagementApp
//
//  Created by manohara reddy p on 17/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import Foundation



enum DocType {
    case Pdf
    case Image
}

class Document {
    let docTypeImage:DocType
    let docName:String
    let docSentDate:String
    let docSize:String
    let fromGroup:String
    var setFavourite:Bool
    let sender:String
    init(docTypeImage:DocType,docName:String,docSentDate:String,docSize:String,fromGroup:String,setFavourite:Bool,sender:String)
    {
   self.docTypeImage = docTypeImage
    self.docName = docName
    self.docSentDate = docSentDate
    self.docSize = docSize
    self.fromGroup = fromGroup
    self.setFavourite = setFavourite
    self.sender = sender
    }
    
}