//
//  StudentCollectionViewCell.swift
//  TrainingManagementApp
//
//  Created by manohara reddy p on 15/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class StudentCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var studentImage: UIImageView!
    @IBOutlet weak var studentName: UILabel!
    @IBOutlet weak var studentEmail: UILabel!
}
