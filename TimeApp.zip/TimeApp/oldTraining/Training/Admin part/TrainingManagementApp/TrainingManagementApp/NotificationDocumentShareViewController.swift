//
//  NotificationDocumentShareViewController.swift
//  TrainingManagementApp
//
//  Created by manohara reddy p on 14/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class NotificationDocumentShareTableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        title = "Document"
       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

extension NotificationDocumentShareTableViewController
{
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
            return UITableViewAutomaticDimension
    }
    
    override func tableView(tableView: UITableView, estimatedHeightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
       return 44
    }
}
