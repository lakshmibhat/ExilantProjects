//
//  GroupsViewController.swift
//  TrainingManagementApp
//
//  Created by manohara reddy p on 13/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class GroupsViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    @IBOutlet weak var groupsNameTable: UITableView!
    
    
    
    var groupNames = ["Java","Objective-C","Swift"]
    var group = [String]()
    var roles = ["Admin","Student","Trainer","Admin","Admin","Admin","Admin","Admin","Admin","Admin","Admin","Admin"]
    var selectedRole:String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
      //  groupsNameTable.registerClass(UITableViewCell.self, forCellReuseIdentifier: "Cell")
                                 
        groupsNameTable.delegate = self
        groupsNameTable.dataSource = self
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
}

extension GroupsViewController
{
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return groupNames.count
        
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("Cell")!
        cell.textLabel!.text = groupNames[indexPath.row]
        cell.detailTextLabel!.text = roles[indexPath.row]
        
        return cell
        
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        navigationItem.backBarButtonItem = UIBarButtonItem(title:"Back", style:.Plain, target: nil, action: nil)
        let cell = tableView.cellForRowAtIndexPath(indexPath)
        selectedRole = cell?.detailTextLabel?.text
        performSegueWithIdentifier("Trainer", sender: self)
    }
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "Trainer"
        {
            let viewController = segue.destinationViewController as! TrainerHomeTableViewController
            viewController.role = selectedRole
            
        }
        else
        {
            let viewController = segue.destinationViewController as! AdminSessionTableViewController
            // self.performSegueWithIdentifier("Admin", sender: self)
        }
    }
    
    @IBAction func createGroup(sender: AnyObject)
   {
                   
                let alert = UIAlertController(title: "New Group Name",
                                              message: "Add a new group Details",
                                              preferredStyle: .Alert)
        
                let saveAction = UIAlertAction(title: "Save",
                                               style: .Default,
                                               handler: { (action:UIAlertAction) -> Void in
        
                                             let textField = alert.textFields!.first
                                             self.groupNames.append(textField!.text!)
//                                                
//                                                let textField1 = alert.textFields!.first
//                                                self.roles.append(textField1!.text!)
//
                                                
                                            self.groupsNameTable.reloadData()
                                                
                                                self.performSegueWithIdentifier("Admin", sender: self)
                                                
    })
    
  
    
                let cancelAction = UIAlertAction(title: "Cancel",
                                                 style: .Destructive) { (action: UIAlertAction) -> Void in
                }
        
                alert.addTextFieldWithConfigurationHandler
                    {
                        (textField: UITextField) -> Void in
                        textField.placeholder = "Group Name"
                        textField.textColor = UIColor.redColor()
                }
//    alert.addTextFieldWithConfigurationHandler
//        {
//            (textField: UITextField) -> Void in
//            textField.placeholder = "Group Details"
//            
//    }
    
    
    
                alert.addAction(saveAction)
                alert.addAction(cancelAction)
                
                presentViewController(alert,
                                      animated: true,
                                      completion: nil)
    
    
    
    

    }
    
func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == UITableViewCellEditingStyle.Delete {
            groupNames.removeAtIndex(indexPath.row)
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: UITableViewRowAnimation.Automatic)
        }
    }
    
    @IBAction func CancelToGroups(segue:UIStoryboardSegue)
    {
        
    }
}
