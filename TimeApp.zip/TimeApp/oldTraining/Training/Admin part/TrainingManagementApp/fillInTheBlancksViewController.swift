//
//  fillInTheBlancksViewController.swift
//  TraningApp
//
//  Created by basagond a mugganauar on 09/06/16.
//  Copyright © 2016 basagond a mugganauar. All rights reserved.
//

import UIKit

class fillInTheBlancksViewController: UIViewController {

    @IBOutlet var questionPartOne: UITextView!
    
    @IBOutlet var answer: UITextField!
    
    @IBOutlet var detailDescription: UITextView!
    @IBOutlet var questionNumber: UILabel!
    @IBOutlet var checkUncheckButton: UIButton!
    var question : String = ""
    var ans : String = ""
    var qNum : String = ""
    @IBOutlet weak var nextButton: UIButton!

    let checkedImage = UIImage(named: "checked.png")! as UIImage
    let uncheckedImage = UIImage(named: "unchecked.png")! as UIImage
    
//    var coreData : CoreData?
    
    var count = 1
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        coreData = CoreData()
        questionPartOne.text = question
        answer.text = ans
        if answer.text != ""{
            nextButton.setTitle("save", forState: .Normal)
            questionNumber.text = qNum
        }
        else{
//            count = coreData!.fetch(String(FillInTheBlanks)).count + coreData!.fetch(String(YesNo)).count + coreData!.fetch(String(MCQ)).count + 1
            questionNumber.text = String(count)
        }
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
//    @IBAction func clickToGoBack(sender: UIButton) {
//        self.performSegueWithIdentifier("unwindToViewController1", sender: self)
//    }
    
    @IBAction func next(sender: UIButton) {
        if sender.titleLabel?.text != "save"{
        if (questionPartOne.text != "" && answer.text != "")
        {
//            coreData?.insert(questionNumber.text!, questionPartOne: questionPartOne.text!, answer: answer.text!, descriptive: detailDescription.text!)
            
//            count = coreData!.fetch(String(FillInTheBlanks)).count + coreData!.fetch(String(YesNo)).count + coreData!.fetch(String(MCQ)).count + 1
            questionNumber.text = String(count)
            questionPartOne.text = ""
            answer.text = ""
            detailDescription.text = ""
        }
        else
        {
            let alertController = UIAlertController(title: "Textfield blank", message:
                "Please enter text in textfield", preferredStyle: UIAlertControllerStyle.Alert)
            alertController.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Default,
                handler: nil))
            self.presentViewController(alertController, animated: true, completion: nil)
            
        }
        }
        else{
//            if (questionPartOne.text != "" && answer.text != ""){
////                let fib = coreData?.createInstanceOfEntity(String(FillInTheBlanks),qNum: qNum)
//                (fib as! FillInTheBlanks).questionNumber = qNum
//                (fib as! FillInTheBlanks).answer = answer.text
//                (fib as! FillInTheBlanks).questionPartOne = questionPartOne.text
//                (fib as! FillInTheBlanks).descriptive = detailDescription.text
//                
//                //let fib = FIB(answer: answer.text!,descriptive: detailDescription.text,questionNumber: qNum,questionPartOne: questionPartOne.text)
//                
//                coreData?.update(fib!,entityName: String(FillInTheBlanks))
//            }
        }

    }
    
//    @IBAction func clickToSaveTheQuestion(sender: UIBarButtonItem) {
//        let secondViewController = self.storyboard?.instantiateViewControllerWithIdentifier("Home") as! TemplatesTableViewController
//        self.presentViewController(secondViewController, animated: true, completion: nil)
//    }
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "DoneButtonSegue" {
            let destinationController = segue.destinationViewController as! FillInTheBlankListTableViewController
//            coreData?.fetch()
//              destinationController.fillInTheBlanks = coreData?.fetch(String(FillInTheBlanks)) as! [FillInTheBlanks]
            destinationController.fillTheBlanks = self
            
        }
    }
    
    @IBAction func enableDisable(sender: UIButton) {
        
        if(sender.tag == 0) {
            checkUncheckButton.setImage(checkedImage, forState: .Normal)
            checkUncheckButton.tag = 1
        }
        else
            if(sender.tag == 1) {
                checkUncheckButton.setImage(uncheckedImage, forState: .Normal)
                checkUncheckButton.tag = 0
        }
    }

    @IBAction func resetAction(sender: UIButton) {
        questionPartOne.text = ""
        answer.text = ""
        detailDescription.text = ""
    }
    @IBAction func backToFIB(segue:UIStoryboardSegue)
    {
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
