//
//  MTFListViewController.swift
//  TraningApp
//
//  Created by basagond a mugganauar on 27/06/16.
//  Copyright © 2016 basagond a mugganauar. All rights reserved.
//

import UIKit

class MTFListViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    let templates = ["1. My name is ", "2. is a apple CEO", "3. BCCI is board", "4. Winner of IPL 9"]
    
    
    @IBOutlet var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - Table view data source
    
     func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        
        return 1
    }
    
     func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return templates.count
    }
    
    
     func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let newData = ["Name", "Tim-Cook", "Indian Cricket","SRH"]
        let cell = tableView.dequeueReusableCellWithIdentifier("Cell", forIndexPath: indexPath)
        
        
        cell.textLabel?.text = templates[indexPath.row]
        let imageFilename = templates[indexPath.row].lowercaseString.stringByReplacingOccurrencesOfString(" ", withString: "_", options: [], range: nil)
        
        
        cell.imageView?.image = UIImage(named: imageFilename)
        cell.separatorInset.left = 20.0
        cell.separatorInset.right = 20.0
        cell.separatorInset.top = 50.0
        cell.separatorInset.bottom = 50.0
        cell.layer.cornerRadius = 20.0
        
        cell.imageView!.clipsToBounds = true;
        cell.imageView!.layer.borderWidth = 2;
        
        cell.imageView!.layer.cornerRadius = 10;
        cell.imageView!.sizeToFit()
        var newLabel1 = UILabel(frame: CGRectMake(200.0, 35, 200.0, 15.0))
        //newLabel1.text = newData[indexPath.row]
        newLabel1.tag = 1
        newLabel1.textColor = UIColor.redColor()
        cell.addSubview(newLabel1)
        
        return cell
    }
    
    @IBAction func clickToSave(sender: UIBarButtonItem) {
        
        
        let alertView = UIAlertController(title: "Success", message: "Questions submitted successfully.", preferredStyle: .Alert)
        
        
        alertView.addAction(UIAlertAction(title: "OK", style: .Default, handler:nil
            //            {
            //                [unowned self] (action) -> Void in
            //
            //                let nextViewController = self.storyboard?.instantiateViewControllerWithIdentifier("Home") as! TemplatesTableViewController
            //                self.presentViewController(nextViewController, animated: true, completion: nil)
            //        }
            ))
        
        presentViewController(alertView, animated: true, completion: nil)
        
    }
    
    
    @IBAction func previewAction(sender: UIBarButtonItem) {
        let secondViewController = self.storyboard?.instantiateViewControllerWithIdentifier("Question") as! QuestionsViewController
        self.presentViewController(secondViewController, animated: true, completion: nil)
        
    }
    
     func tableView(tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        
        let headerView = view as! UITableViewHeaderFooterView
        headerView.textLabel?.textColor = UIColor.orangeColor()
        headerView.textLabel?.font = UIFont(name: "Avenir", size: 25.0)
    }
     func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let nextViewController = self.storyboard?.instantiateViewControllerWithIdentifier("MTF") as! matchTheFollowingViewController
        self.presentViewController(nextViewController, animated: true, completion: nil)
    }
    @IBAction func backToListMTF(segue:UIStoryboardSegue)
    {
        
    }
}

