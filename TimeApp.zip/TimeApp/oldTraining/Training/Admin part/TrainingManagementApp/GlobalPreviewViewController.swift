//
//  GlobalPreviewViewController.swift
//  TrainingManagementApp
//
//  Created by lakshmi r bhat on 04/07/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class GlobalPreviewViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

   
    var flag : Bool = true
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
               // Do any additional setup after loading the view.
    }
    
    @IBAction func addQuestion(sender: UIButton){
        let secondViewController = self.storyboard?.instantiateViewControllerWithIdentifier("aaa")
        self.presentViewController(secondViewController!, animated: true, completion: nil)
    }
    
    @IBAction func editOOOuestion(sender: UIButton) {
        let secondViewController = self.storyboard?.instantiateViewControllerWithIdentifier("OOO") as! OddOneOutViewController
         self.presentViewController(secondViewController, animated: true, completion: nil)

    }
    
    @IBAction func editMTFuestion(sender: UIButton) {
        let secondViewController = self.storyboard?.instantiateViewControllerWithIdentifier("MTF") as! matchTheFollowingViewController
        self.presentViewController(secondViewController, animated: true, completion: nil)
        
    }
    
    @IBAction func editMCQuestion(sender: UIButton) {
        let secondViewController = self.storyboard?.instantiateViewControllerWithIdentifier("MCQ") as! mcqViewController
        secondViewController.qNum = (sender.superview?.superview as! MCQuestionTableViewCell).questionNumber.text!
        secondViewController.question = (sender.superview?.superview as! MCQuestionTableViewCell).questionLabel.text!
        for i in 0..<(sender.superview?.superview as! MCQuestionTableViewCell).options.count{
            secondViewController.options[i] = (sender.superview?.superview as! MCQuestionTableViewCell).options[i].text!
            
        }
        for button in (sender.superview?.superview as! MCQuestionTableViewCell).checkBoxButtons{
            if button.imageView?.image == UIImage(named: "checked")! as UIImage{
                secondViewController.answer = (sender.superview?.superview as! MCQuestionTableViewCell).options[(sender.superview?.superview as! MCQuestionTableViewCell).checkBoxButtons.indexOf(button)!].text
            }
        }
        
        self.presentViewController(secondViewController, animated: true, completion: nil)
    }
    @IBAction func editFIBQuestion(sender: UIButton){
        let secondViewController = self.storyboard?.instantiateViewControllerWithIdentifier("FIB") as! fillInTheBlancksViewController
        secondViewController.qNum = (sender.superview?.superview as! FIBTableViewCell1).fibQuestionNumber.text!
        secondViewController.question =  (sender.superview?.superview as! FIBTableViewCell1).fibQuestion.text!
        secondViewController.ans =  (sender.superview?.superview as! FIBTableViewCell1).fibAnswer.text!
        self.presentViewController(secondViewController, animated: true, completion: nil)
    }
    @IBAction func editYNQuestion(sender: UIButton){
        let secondViewController = self.storyboard?.instantiateViewControllerWithIdentifier("YN") as! YesOrNoViewController
        secondViewController.ques = (sender.superview?.superview as! YNTableViewCell).YNQuestion.text!
        secondViewController.qNum = (sender.superview?.superview as! YNTableViewCell).YNQuestionNumber.text!
        for button in (sender.superview?.superview as! YNTableViewCell).radioButton{
            if button.isChecked{
                
                if(sender.superview?.superview as! YNTableViewCell).options[(sender.superview?.superview as! YNTableViewCell).radioButton.indexOf(button)!].text! == "True"{
                    
                    secondViewController.answer = true
                }
                else{
                    secondViewController.answer = false
                }
            }
            
            
        }
        
        self.presentViewController(secondViewController, animated: true, completion: nil)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) ->
        Int {
            return 5
               }
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath:
        NSIndexPath) -> UITableViewCell {
        var cellIdentifier : String
        var cell = UITableViewCell()
        if indexPath.row == 0{
            cellIdentifier = "OOOCell"
            cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier,forIndexPath: indexPath)
            (cell as! OddOneOutQuesTableViewCell).oooQuestionNumber.text = String(indexPath.row + 1)
        }
        if indexPath.row ==  1{
            cellIdentifier = "FIBCell"
            
            cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier,forIndexPath: indexPath)
            (cell as! FIBTableViewCell1).fibQuestionNumber.text = String(indexPath.row + 1)
        }
        if indexPath.row ==  2{
            cellIdentifier = "MCQCell"
            cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier,forIndexPath: indexPath)
            (cell as! MCQuestionTableViewCell).checkBoxButtons[2].isChecked = true
            (cell as! MCQuestionTableViewCell).questionNumber.text = String(indexPath.row + 1)
        }
        if indexPath.row ==  3{
            cellIdentifier = "YNCell"
            
            cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier,forIndexPath: indexPath)
            (cell as! YNTableViewCell).radioButton[1].isChecked = true
            (cell as! YNTableViewCell).YNQuestionNumber.text = String(indexPath.row + 1)
        }
        
        if indexPath.row ==  4{
            cellIdentifier = "MTFCell"
            cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier,forIndexPath: indexPath)
            (cell as! MTFTableViewCell1).mtfQuestionNumber.text = String(indexPath.row + 1)
        }
        
        
               return cell }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    

}
