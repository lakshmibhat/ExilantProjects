//
//  QuestionsPreviewController.swift
//  TraningApp
//
//  Created by vedashree k on 16/06/16.
//  Copyright © 2016 basagond a mugganauar. All rights reserved.
//

import UIKit

class QuestionsPreviewController: UIViewController {

//    var coreData : CoreData?
    var mcqCount : Int = 0
    var fibCount : Int = 0
    var YNCount : Int = 0
    var mcqArray : [MCQ] = []
    var fibArray : [FillInTheBlanks] = []
//    var YNArray : [YesNo] = []
//    let mcqTableViewCell = MCQuestionTableViewCell()
//    var flag : Bool = true

    
    override func viewDidLoad() {
        super.viewDidLoad()
//        coreData = CoreData()
        YNCount = 0
        fibCount = 0
        mcqCount = 0
        // Do any additional setup after loading the view.
    }
    
//    @IBAction func editMCQuestion(sender: UIButton) {
//        let secondViewController = self.storyboard?.instantiateViewControllerWithIdentifier("MCQ") as! mcqViewController
//        secondViewController.qNum = (sender.superview?.superview as! MCQuestionTableViewCell).questionNumber.text!
//        secondViewController.question = (sender.superview?.superview as! MCQuestionTableViewCell).questionLabel.text!
//        for i in 0..<(sender.superview?.superview as! MCQuestionTableViewCell).options.count{
//            secondViewController.options[i] = (sender.superview?.superview as! MCQuestionTableViewCell).options[i].text!
//            
//        }
//        for button in (sender.superview?.superview as! MCQuestionTableViewCell).checkBoxButtons{
//            if button.imageView?.image == UIImage(named: "checked")! as UIImage{
//secondViewController.answer = (sender.superview?.superview as! MCQuestionTableViewCell).options[(sender.superview?.superview as! MCQuestionTableViewCell).checkBoxButtons.indexOf(button)!].text
//            }
//        }
//
//        self.presentViewController(secondViewController, animated: true, completion: nil)
//    }
//    @IBAction func editFIBQuestion(sender: UIButton){
//        let secondViewController = self.storyboard?.instantiateViewControllerWithIdentifier("FIB") as! fillInTheBlancksViewController
//        secondViewController.qNum = (sender.superview?.superview as! FIBTableViewCell1).fibQuestionNumber.text!
//        secondViewController.question =  (sender.superview?.superview as! FIBTableViewCell1).fibQuestion.text!
//        secondViewController.ans =  (sender.superview?.superview as! FIBTableViewCell1).fibAnswer.text!
//        self.presentViewController(secondViewController, animated: true, completion: nil)
//    }
//    @IBAction func editYNQuestion(sender: UIButton){
//         let secondViewController = self.storyboard?.instantiateViewControllerWithIdentifier("YN") as! YesOrNoViewController
//        secondViewController.ques = (sender.superview?.superview as! YNTableViewCell).YNQuestion.text!
//        secondViewController.qNum = (sender.superview?.superview as! YNTableViewCell).YNQuestionNumber.text!
//        for button in (sender.superview?.superview as! YNTableViewCell).radioButton{
//            if button.isChecked{
//                
//                if(sender.superview?.superview as! YNTableViewCell).options[(sender.superview?.superview as! YNTableViewCell).radioButton.indexOf(button)!].text! == "True"{
//                    
//                    secondViewController.answer = true
//                }
//                else{
//                    secondViewController.answer = false
//                }
//            }
//            
//            
//        }
//
//        self.presentViewController(secondViewController, animated: true, completion: nil)
//    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
//    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) ->
//        Int {
////            YNCount = (coreData?.fetch(String(YesNo)).count)!
////            mcqCount = (coreData?.fetch(String(MCQ)).count)!
////            mcqArray = coreData?.fetch(String(MCQ)) as! [MCQ]
////            fibCount = (coreData?.fetch(String(FillInTheBlanks)).count)!
////            fibArray = coreData?.fetch(String(FillInTheBlanks)) as! [FillInTheBlanks]
////            YNArray = coreData?.fetch(String(YesNo)) as! [YesNo]
//            
//            if mcqCount + fibCount + YNCount == 0{
//                
//                return 5
//            }
//            else{
//                // Return the number of rows in the section.
//                return mcqCount + fibCount + YNCount + 5
//            }
//    }
//    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath:
//        NSIndexPath) -> UITableViewCell {
//        var cellIdentifier : String
//        var cell = UITableViewCell()
//        if indexPath.row == mcqCount + fibCount + YNCount{
//            cellIdentifier = "OOOCell"
//            cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier,forIndexPath: indexPath)
//            //(cell as! OddOneOutQuesTableViewCell).oooQuestionNumber.text = String(indexPath.row + 1)
//        }
//        if indexPath.row == mcqCount + fibCount + YNCount + 1{
//            cellIdentifier = "FIBCell"
//          
//            cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier,forIndexPath: indexPath)
//              (cell as! FIBTableViewCell1).fibQuestionNumber.text = String(indexPath.row + 1)
//        }
//        if indexPath.row == mcqCount + fibCount + YNCount + 2{
//            cellIdentifier = "MCQCell"
//            cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier,forIndexPath: indexPath)
//            (cell as! MCQuestionTableViewCell).checkBoxButtons[2].isChecked = true
//            (cell as! MCQuestionTableViewCell).questionNumber.text = String(indexPath.row + 1)
//        }
//        if indexPath.row == mcqCount + fibCount + YNCount + 3{
//            cellIdentifier = "YNCell"
//            
//            cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier,forIndexPath: indexPath)
//            (cell as! YNTableViewCell).radioButton[1].isChecked = true
//            (cell as! YNTableViewCell).YNQuestionNumber.text = String(indexPath.row + 1)
//        }
//        
//        if indexPath.row == mcqCount + fibCount + YNCount + 4{
//            cellIdentifier = "MTFCell"
//            cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier,forIndexPath: indexPath)
//            (cell as! MTFTableViewCell1).mtfQuestionNumber.text = String(indexPath.row + 1)
//        }
//        
//
//        if flag{
//            for fib in fibArray{
//                if String(indexPath.row + 1) == fib.questionNumber{
//                    cellIdentifier = "FIBCell"
//                    cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier,forIndexPath: indexPath)
//                    (cell as! FIBTableViewCell1).fibQuestionNumber.text = String(indexPath.row + 1)
//                    (cell as! FIBTableViewCell1).fibQuestion.text = fib.questionPartOne!
//                    (cell as! FIBTableViewCell1).fibAnswer.text = fib.answer
//                    flag = false
//                    break
//                }
//            }
//        }
//        
//        if flag{
//            for mcq in mcqArray{
//                if String(indexPath.row + 1) == mcq.noOfQue{
//                    cellIdentifier = "MCQCell"
//                    cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier,forIndexPath: indexPath)
//                    (cell as! MCQuestionTableViewCell).questionNumber.text = String(indexPath.row + 1)
//                    (cell as! MCQuestionTableViewCell).questionLabel.text = mcq.question
//                    (cell as! MCQuestionTableViewCell).options[0].text = mcq.option1
//                    (cell as! MCQuestionTableViewCell).options[1].text = mcq.option2
//                    (cell as! MCQuestionTableViewCell).options[2].text = mcq.option3
//                    (cell as! MCQuestionTableViewCell).options[3].text = mcq.option4
//                    let answer = mcq.answer
//                    for option in (cell as! MCQuestionTableViewCell).options{
//                        if ((option.text?.caseInsensitiveCompare(answer!)) ==  NSComparisonResult.OrderedSame){
//                            (cell as! MCQuestionTableViewCell).checkBoxButtons[(cell as! MCQuestionTableViewCell).options.indexOf(option)!].isChecked = true
//                        }
//                    }
//                    flag = false
//                    break
//                }
//            }
//        }
//        
//        if flag{
//            for yn in YNArray{
//                if String(indexPath.row + 1) == yn.queNum{
//                    cellIdentifier = "YNCell"
//                    cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier,forIndexPath: indexPath)
//                    (cell as! YNTableViewCell).YNQuestionNumber.text = String(indexPath.row + 1)
//                    (cell as! YNTableViewCell).YNQuestion.text = yn.question
//                    let trueOrFalse = yn.answer
//                    var answer : String = ""
//                    if trueOrFalse == 0{
//                        answer = "false"
//                    }
//                    else{
//                        answer = "true"
//                    }
//                    for option in (cell as! YNTableViewCell).options{
//                        if ((option.text?.caseInsensitiveCompare(answer)) ==  NSComparisonResult.OrderedSame){
//                            
//                            (cell as! YNTableViewCell).radioButton[(cell as! YNTableViewCell).options.indexOf(option)!].isChecked = true
//                            
//                        }
//                        else{
//                            (cell as! YNTableViewCell).radioButton[(cell as! YNTableViewCell).options.indexOf(option)!].isChecked = false
//                        }
//                    }
//                    break
//                }
//            }
//        }
//        
//               flag = true
//
//        print(indexPath.row)
//        return cell }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    

}
