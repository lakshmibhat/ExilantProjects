//
//  MCQuestionTableViewCell.swift
//  TrainingManagementApp
//
//  Created by vedashree k on 04/07/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class MCQuestionTableViewCell: UITableViewCell {
    @IBOutlet var options: [UILabel]!
    
    @IBOutlet var checkBoxButtons: [CheckBox]!
    @IBOutlet weak var questionNumber: UILabel!
    @IBOutlet weak var questionLabel: UILabel!
    
    @IBOutlet weak var optionA: UILabel!
    
    @IBOutlet weak var optionB: UILabel!
    
    @IBOutlet weak var optionC: UILabel!
    
    @IBOutlet weak var optionD: UILabel!
    let checkedImage = UIImage(named: "checked")! as UIImage
    let uncheckedImage = UIImage(named: "unchecked")! as UIImage
    // var isChecked : Bool = false
    
    @IBAction func selectAnswer(sender: UIButton) {
        for button in checkBoxButtons{
            if button != sender{
                if button.isChecked == true{
                    button.isChecked = false
                }
            }
            else{
                button.isChecked = !(button.isChecked)
            }
        }

}
}
