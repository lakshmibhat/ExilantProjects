//
//  MaterialTableViewCell.swift
//  TrainingManagementApp
//
//  Created by sowmyashree nanjappa on 14/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class MaterialTableViewCell: UITableViewCell {

    @IBOutlet var documentImage: UIImageView!
    @IBOutlet var title: UILabel!
    @IBOutlet var date: UILabel!
   
    @IBOutlet var postedBy: UILabel!
    @IBOutlet var size: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
