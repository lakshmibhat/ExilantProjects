//
//  MCQ.swift
//  TraningApp
//
//  Created by lakshmi r bhat on 14/06/16.
//  Copyright © 2016 basagond a mugganauar. All rights reserved.
//

import Foundation
import CoreData


class MCQ: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
