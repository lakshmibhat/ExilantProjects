//
//  QuestionTableViewCell.swift
//  TrainingManagementApp
//
//  Created by sowmyashree nanjappa on 14/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import UIKit

class QuestionTableViewCell: UITableViewCell {

    @IBOutlet var askedBy: UILabel!
    
    @IBOutlet var time: UILabel!
    @IBOutlet var question: UILabel!
    
    @IBOutlet var date: UILabel!
   
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
