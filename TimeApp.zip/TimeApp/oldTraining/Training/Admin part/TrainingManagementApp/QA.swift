//
//  QA.swift
//  TrainingManagementApp
//
//  Created by sowmyashree nanjappa on 21/06/16.
//  Copyright © 2016 exilant. All rights reserved.
//

import Foundation

class QA: NSObject
{
    let question:String?
    let by:String?
    var numberOfAnswers:Int?
    init(question:String,by:String,numberOfAnswers:Int) {
        self.question = question
        self.by = by
        self.numberOfAnswers = numberOfAnswers
    }



}