//
//  JumbledCollectionViewCell.swift
//  StudentAssessment
//
//  Created by lakshmi r bhat on 28/06/16.
//  Copyright © 2016 varsha sambhajirao aware. All rights reserved.
//

import UIKit

class JumbledCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var label: UILabel!
    
    var baseBackgroundColor : UIColor?
    
    var dragging : Bool = false {
        
        didSet {
            
            if dragging == true {
                
                self.baseBackgroundColor = self.backgroundColor
                self.backgroundColor = UIColor.clearColor()
                
            } else {
                
                self.backgroundColor = self.baseBackgroundColor
                
            }
        }
    }
   
}
