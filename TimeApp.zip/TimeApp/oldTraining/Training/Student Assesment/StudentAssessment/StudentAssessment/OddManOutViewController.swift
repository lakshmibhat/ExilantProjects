//
//  OddManOutViewController.swift
//  StudentAssessment
//
//  Created by varsha sambhajirao aware on 27/06/16.
//  Copyright © 2016 varsha sambhajirao aware. All rights reserved.
//

import UIKit

class OddManOutViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return 4
        
    }
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath:
        NSIndexPath) -> UITableViewCell {
        var cellIdentifier : String
        var cell = UITableViewCell()
        if indexPath.row == 0{
            cellIdentifier = "Cell1"
            cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier,forIndexPath: indexPath)
        }
        if indexPath.row == 1{
            cellIdentifier = "Cell2"
            cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier,forIndexPath: indexPath)
        }
        if indexPath.row == 2{
            cellIdentifier = "Cell3"
            //tableView.selectRowAtIndexPath(indexPath, animated: true, scrollPosition: UITableViewScrollPosition.None)
            cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier,forIndexPath: indexPath)
        }
        if indexPath.row == 3{
            cellIdentifier = "Cell4"
            cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier,forIndexPath: indexPath)
        }
//        if indexPath.row == 4{
//            cellIdentifier = "Cell5"
//            cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier,forIndexPath: indexPath)
//        }
        
        return cell
        
        
    }




    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
