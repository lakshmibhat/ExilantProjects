//
//  ClipboardCell.swift
//  NoteApp
//
//  Created by swathi m on 5/23/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import UIKit

class ClipboardCell: UITableViewCell {

    @IBOutlet var search: UISearchBar!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
