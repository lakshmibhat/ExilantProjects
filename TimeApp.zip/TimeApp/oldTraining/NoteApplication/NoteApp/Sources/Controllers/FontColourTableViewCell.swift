//
//  FontColourTableViewCell.swift
//  NoteApp
//
//  Created by lakshmi r bhat on 02/08/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import UIKit

class FontColourTableViewCell: UITableViewCell {
    
    var presentVIewController = FontSettingTableViewController()
    @IBOutlet weak var black: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }


}
