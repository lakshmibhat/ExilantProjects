//
//  NoteListTableViewController.swift
//  NoteApp
//
//  Created by swathi m on 6/8/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import UIKit

class NoteListTableViewController: UITableViewController, ENSideMenuDelegate,UISearchBarDelegate, UISearchDisplayDelegate,UISearchResultsUpdating, UIPopoverPresentationControllerDelegate {
//    let notify = NotificationModel()
    var noteModel = NoteFileModel()
    @IBOutlet var myTableView: UITableView!
    
    @IBOutlet var menuButton: UIBarButtonItem!
    @IBOutlet var createFolderButton: UIBarButtonItem!
    
     var searchController:UISearchController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
               searchController = UISearchController(searchResultsController: nil)
        searchController.hidesNavigationBarDuringPresentation = false

        navigationItem.titleView = searchController.searchBar
        
        searchController.searchResultsUpdater = self
        searchController.dimsBackgroundDuringPresentation = false
        self.tableView.tableFooterView = UIView()
        NSNotificationCenter.defaultCenter().addObserver(self, selector:#selector(self.moveLeftNotification(_:)), name: NotificationModel.left.rawValue, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector:#selector(self.moveRightNotification(_:)), name: NotificationModel.right.rawValue, object: nil)
                // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }
    func moveLeftNotification(notification: NSNotification){
        //Take Action on Notification
        UIView.animateWithDuration(0.4, animations: {
            self.view.frame.origin.x = MyNoteMenuTableViewController().view.frame.size.width/2
            
        })
    }
    func moveRightNotification(notification: NSNotification){
        //Take Action on Notification
        UIView.animateWithDuration(0.4, animations: {
            self.view.frame.origin.x = 0
            
        })
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        if searchController.active {
            navigationItem.leftBarButtonItem = nil
            navigationItem.rightBarButtonItem = nil
            return noteModel.searchResults.count
        } else {
            navigationItem.leftBarButtonItem = menuButton
            navigationItem.rightBarButtonItem = createFolderButton
            return noteModel.noteNames.count
        }

    }
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 50.0
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cellIdentifier = "Cell"
        let cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier,
                                                               forIndexPath: indexPath)
//        let noteName = (searchController.active) ? noteModel.searchResults[indexPath.row] :
//            noteModel.noteNames[indexPath.row]
        // Configure the cell...
        cell.textLabel?.text = noteModel.noteNames[indexPath.row]
//        let imageFilename = "Files"
        let cellImg : UIImageView = UIImageView(frame: CGRectMake(5, 5, 40, 40))
        cellImg.image = UIImage(named: noteModel.fileImageName)
        //cell.addSubview(cellImg)
        //cell.imageView?.image = imageFilename
        cell.imageView?.image = UIImage(named: noteModel.fileImageName)
        return cell
    }

    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        if searchController.active {
            return false
        } else {
            return true
        }
    }
    
    override func prefersStatusBarHidden() -> Bool {
        return true
    }
    
    @IBAction func toggleSideMenu(sender: AnyObject) {
        
        toggleSideMenuView()
        
            UIView.animateWithDuration(0.4, animations: {
               self.view.frame.origin.x = self.isSideMenuOpen() ? (self.view.frame.origin.x + 180) : (self.view.frame.origin.x - 180)
                
            })
        

    }
    
    func filterContentForSearchText(searchText: String) {
        noteModel.searchResults = noteModel.noteNames.filter({ (noteName:String) -> Bool in
            for item in noteModel.noteNames {
                let nameMatch = item.rangeOfString(searchText, options:                NSStringCompareOptions.CaseInsensitiveSearch)
                return nameMatch != nil
                
                
            }
            return  false
            
        })
    }
    
    func updateSearchResultsForSearchController(searchController:
        UISearchController) {
        if let searchText = searchController.searchBar.text {
            filterContentForSearchText(searchText)
            myTableView.reloadData()
        } }

    
    @IBAction func addNewFolderAction(sender: UIBarButtonItem) {

        let title = NSLocalizedString(noteModel.alertTitle, comment: "")
        let message = NSLocalizedString(noteModel.alertMessage, comment: "")
        let cancelButtonTitle = NSLocalizedString(noteModel.cancelText, comment: "")
        let otherButtonTitle = NSLocalizedString("OK", comment: "")
        
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .Alert)
        
        // Add the text field for text entry.
        alertController.addTextFieldWithConfigurationHandler { textField in
            // If you need to customize the text field, you can do so here.
        }
        let textField = alertController.textFields![0]
        // Create the actions.
        let cancelAction = UIAlertAction(title: cancelButtonTitle, style: .Cancel) { _ in
        }
        
        let otherAction = UIAlertAction(title: otherButtonTitle, style: .Default) { _ in
            self.noteModel.noteNames.append(textField.text!)
            self.tableView.reloadData()
        }
        
        // Add the actions.
        alertController.addAction(cancelAction)
        alertController.addAction(otherAction)
        
        presentViewController(alertController, animated: true, completion: nil)
        
    }
    override func tableView(tableView: UITableView, commitEditingStyle
        editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath:
        NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            noteModel.noteNames.removeAtIndex(indexPath.row)
        }
        tableView.reloadData()
    }
    /*
     // Override to support conditional editing of the table view.
     override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
     // Return false if you do not want the specified item to be editable.
     return true
     }
     */
    
    /*
     // Override to support editing the table view.
     override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
     if editingStyle == .Delete {
     // Delete the row from the data source
     tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
     } else if editingStyle == .Insert {
     // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
     }
     }
     */
    
    /*
     // Override to support rearranging the table view.
     override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {
     
     }
     */
    
    /*
     // Override to support conditional rearranging of the table view.
     override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
     // Return false if you do not want the item to be re-orderable.
     return true
     }
     */
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */

}
