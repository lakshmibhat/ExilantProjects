//
//  FontSettingTableViewController.swift
//  NoteApp
//
//  Created by lakshmi r bhat on 25/07/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import UIKit

class FontSettingTableViewController: UITableViewController {
    var fontOption : Int = 0
   

    override func viewDidLoad() {
        super.viewDidLoad()
        
//self.view.add
//        self.navigationController?.navigationItem.leftBarButtonItem = leftButton
//        self.navigationController?.navigationBar.items = [navigationItem]

//        self.navigationItem.rightBarButtonItem?.action = #selector(dismissPopover)
//        self.navigationController?.navigationItem.action = #selector(dismissPopover)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

//    @IBAction func doneAction(sender: UIBarButtonItem) {
//        self.dismissViewControllerAnimated(true, completion: nil)
//
//    }

    func dismissPopover(){
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
//
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 1

    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var cellIdentifier : String
        var cell:UITableViewCell!
//        if fontOption == 1{
            cellIdentifier = "colour"
            cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier,forIndexPath: indexPath) as! FontColourTableViewCell
            

//        }
        if fontOption == 2{
            cellIdentifier = "style"
            cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier,forIndexPath: indexPath) as! FontStylePickerTableViewCell
            
        }
        if fontOption == 3{
            cellIdentifier = "size"
            cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier,forIndexPath: indexPath) as! FontSizeTableViewCell
            
        }
        if fontOption == 4{
            cellIdentifier = "bgcolour"
            cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier,forIndexPath: indexPath)
            
        }
//        }else{
//         cell =  tableView.dequeueReusableCellWithIdentifier("done",forIndexPath: indexPath)
//        }

        // Configure the cell...

        return cell
    }
    
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
       return super.tableView(tableView, heightForRowAtIndexPath: indexPath)
    }

//    @IBAction func done(sender: UIButton) {
//        
//    dismissViewControllerAnimated(true, completion: nil)
//    }
    

    
    @IBAction func buttonSelected(sender: UIButton) {
        
        
    }
    

}
