//
//  ClipBoardViewController.swift
//  NoteApp
//
//  Created by avnish kumar on 21/06/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import UIKit

class ClipBoardViewController: UIViewController,UIPopoverPresentationControllerDelegate {
    
    var gestureRec = UITapGestureRecognizer()

    @IBOutlet var color: UIButton!
    
    @IBOutlet weak var containerView: UIView!
    
    var value = true
      @IBOutlet weak var clipBoardTextView : UITextView!
    @IBOutlet weak var fontView: UIView!

    override func viewDidLoad() {
        super.viewDidLoad()

        NSNotificationCenter.defaultCenter().addObserver(self, selector:#selector(self.moveLeftNotification(_:)), name: NotificationModel.left.rawValue, object: nil)
        NSNotificationCenter.defaultCenter().addObserver(self, selector:#selector(self.moveRightNotification(_:)), name: NotificationModel.right.rawValue, object: nil)
        // Do any additional setup after loading the view.
        performAnimation()
    }
    func createImageView() {
        let image = UIImage(named: <#T##String#>)
    }
   func performAnimation()
   {
    
    UIView.animateWithDuration(0, delay: 0, options: [], animations: {
         self.containerView.transform = CGAffineTransformMakeTranslation(0,-self.fontView.frame.height)
        
        }) { (value) in
           self.fontView.transform = CGAffineTransformMakeTranslation(0, -self.fontView.frame.width)
    }

   }
    override func viewWillAppear(animated: Bool) {
        
        let currentPasteboardContents = UIPasteboard.generalPasteboard().string
        clipBoardTextView.text.appendContentsOf("\n")
        if(currentPasteboardContents != nil){
            clipBoardTextView.text.appendContentsOf("\n")
            clipBoardTextView.text.appendContentsOf(currentPasteboardContents!)
            UIPasteboard.generalPasteboard().string = ""
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func moveLeftNotification(notification: NSNotification){
        //Take Action on Notification
        UIView.animateWithDuration(0.4, animations: {
           self.view.frame.origin.x = self.fontView.frame.size.height
            
        })
    }
    
    func moveRightNotification(notification: NSNotification){
        //Take Action on Notification
        UIView.animateWithDuration(0.4, animations: {
           self.view.frame.origin.x = 0
            
        })
    }

    @IBAction func editFunctions(sender: UIBarButtonItem) {
        if value
        {
         UIView.animateWithDuration(0) {
             self.containerView.transform = CGAffineTransformIdentity
         }
        
         UIView.animateWithDuration(0) {
             self.fontView.transform = CGAffineTransformIdentity
         }
            value = false
        } else {
            performAnimation()
            value = true
        }
        
    }
  

    
    @IBAction func popover(sender: UIButton) {
        let popupController = storyboard!.instantiateViewControllerWithIdentifier("navigator") as! NavigationViewController
//        let leftButton =  UIBarButtonItem(title: "Save", style:   UIBarButtonItemStyle.Plain, target: self, action: #selector(dismissPopover))
//
//        popupController.navigationItem.setRightBarButtonItem(leftButton, animated: true)
//        popupController.navigationItem.rightBarButtonItem?.action = #selector(dismissPopover)
//        let navController = UINavigationController(rootViewController: popupController)
//        navController.navigationItem.rightBarButtonItem?.action = #selector(dismissPopover)
//        navController.navigationBar.items = [navController.navigationItem]
//        navController.navigationItem.setLeftBarButtonItem(leftButton, animated: true)
//        navController.navigationItem.rightBarButtonItems[0]
//        navController.navigationItem.rightBarButtonItem = nil
//        navController.navigationItem.rightBarButtonItem = leftButton
//        popupController.navigationBar.frame = CGRectMake(0, 0, self.view.frame.size.width, 20)
//        navController.navigationBar.frame.origin.y = -10
        //        gestureRec.addTarget(popupController.tableView, action: #selector(dismissPopover) )

//        popupController.fontOption=sender.tag
            popupController.modalPresentationStyle = .Popover

            popupController.preferredContentSize = CGSizeMake(250, 80)
        if let popoverController = popupController.popoverPresentationController {
            let viewForSource = sender as UIView
            popoverController.sourceView = viewForSource
            popoverController.sourceRect = viewForSource.bounds
            popoverController.preferredContentSize
            popoverController.backgroundColor = UIColor.whiteColor()
            popoverController.permittedArrowDirections = .Up
            popoverController.delegate = self
            popupController.editing = false
        }
        presentViewController(popupController, animated: true, completion: nil)
    }
    func adaptivePresentationStyleForPresentationController(controller: UIPresentationController) -> UIModalPresentationStyle{
        return UIModalPresentationStyle.None
    }
    func dismissPopover(){
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    @IBAction func close(segue:UIStoryboardSegue) {
        
    }
//    func dismissPopover(gesture : UITapGestureRecognizer){
//        
//        self.dismissViewControllerAnimated(true, completion: nil)
//    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
//extension ClipBoardViewController: ColourChangeDelegate {
//    func setColor(color: UIColor) {
//        if let actionSheet = self.actionSheet {
//            actionSheet.dismiss()
//        }
//        self.view.backgroundColor = color
//    }
//}
