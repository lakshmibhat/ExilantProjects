# Building an iOS Chat App Using Socket IO

In order to show to you how to make use of the Socket.IO library (client) for iOS and how to achieve real-time communication with a server, I decided that our best hit would be to create a chat application as the demo app of this tutorial. 

For the full tutorial, please check out http://www.appcoda.com/socket-io-chat-app/
