 //
 //  TimeTableView.swift
 //  TimeDragApplication
 //
 //  Created by vedashree k on 02/02/16.
 //  Copyright © 2016 vedashree k. All rights reserved.
 //
 
 import Cocoa
 
 class TimeTableView: NSWindowController
 {
   var calenderObj : Calender?
    let popover = NSPopover()
    var timer = NSTimer()
    var duration = Duration()
    var activityFrame = ActivityFrame()
    var textView : NSTextField?
    let date = NSDate()

    
    var workingDetail :WorkingDetailsWindowController?
    var mainWindowController: MainWindowController?
    var loginWindowController:LoginWindow? = nil

    @IBOutlet var myWindow: NSWindow!
    @IBOutlet weak var userNameDisplayLabel: NSTextField!
    @IBOutlet weak var currentTimeDisplayLabel: NSTextField!
   
    @IBOutlet weak var scrollView: NSScrollView!
    @IBOutlet var submitButton: NSButton!
    
    var mouseLocation: NSPoint
    {
        return NSEvent.mouseLocation()
    }

    override func windowDidLoad()
    {
        super.windowDidLoad()
        
        userNameDisplayLabel.stringValue = (loginWindowController?.userName.stringValue)!
        self.timer = NSTimer.scheduledTimerWithTimeInterval(0.5, target: self, selector: #selector(TimeTableView.tick), userInfo: self, repeats: true)
        
        displayDateInColHeader(date)
        NSNotificationCenter.defaultCenter().addObserver(self, selector: #selector(TimeTableView.updateTable(_:)),name:"load", object: nil)
    }
    
    /* To update the table */
    
    func updateTable(notification: NSNotification){
        //load data here
        self.myTableView.reloadData()
    }
    
    
    /* To update the date on column header */
    
    func displayDateInColHeader(date: NSDate){
        
        //Closes the previously opened calendar popover
        popover.performClose(self)
        
        let days = ["Sun","Mon","Tue","Wed","Thur","Fri","Sat"]
        let calendar = NSCalendar.currentCalendar()
        
        var components = calendar.components([.Day , .Month , .Year], fromDate: date)
        let myComponents = calendar.components(.Weekday, fromDate: date)
        let weekDay = myComponents.weekday
        let date = date.dateByAddingTimeInterval(24*60*60*Double(-(weekDay - 1)))
        let todaysDate = NSDate()
        let comp = calendar.components([.Day , .Month , .Year , .Weekday], fromDate: todaysDate)
        if components.day == comp.day
        {
            myTableView.tableColumns[comp.weekday].identifier = "2"
        }
        else{
            myTableView.tableColumns[comp.weekday].identifier = ""
        }

        for i in 1..<myTableView.tableColumns.count{
            myTableView.tableColumns[i].title = days[i-1]
            
            
            components = calendar.components([.Day , .Month , .Year], fromDate: date.dateByAddingTimeInterval(24*60*60*Double(i - 1)))
            let month = components.month
            let day = components.day
            
            myTableView.tableColumns[i].title = myTableView.tableColumns[i].title + " " + "\(month)/\(day)"
            
            
            
        }
        
        
    }

    var locationOfChangeTap: CGPoint = CGPoint.zero
    var locationX: CGPoint = CGPoint.zero
    var myViews = [NSView]()
    var ActivityLayer :NSView?
    var myButton:NSButton?
    var flag = true
    var scrollVar = 0
    var Hours = 40
    
    @IBOutlet weak var myTableView: NSTableView!
    
    override var windowNibName: String?
    {
        return "TimeTableView"
    }
    
    var timeArray : Array<String> = ["12AM","1AM","2AM","3AM","4AM","5AM","6AM","7AM","8AM","9AM","10AM","11AM","12PM","1PM","2PM","3PM","4PM","5PM","6PM","7PM","8PM","9PM","10PM","11PM"]
    
        
    func tableView(tableView: NSTableView,
        shouldSelectRow row: Int) -> Bool
    {
            return false
    }
    
    func tableView(tableView: NSTableView,
        heightOfRow row: Int) -> CGFloat
    {
            return 100
    }
    
    
    
    @IBAction func draggingOnTableView(sender: NSPanGestureRecognizer)
    {
        
        
        if sender.state == NSGestureRecognizerState.Began
        {
            
            activityFrame.location = sender.locationInView(myTableView)
            ActivityLayer = NSView()
            
            
           getActivityFrameOrigin()
            duration.startTime = getTime()
         
        }
        
        
        locationOfChangeTap = sender.locationInView(myTableView)
        drawDragView()
        
        
        if ActivityLayer?.frame.size.height>0 && sender.state == NSGestureRecognizerState.Ended {
            activityFrame.height=round(activityFrame.height/(myTableView.rowHeight/4))*(myTableView.rowHeight/4)
            ActivityLayer?.frame.size.height = activityFrame.height
            
            activityFrame.location = NSMakePoint(activityFrame.location.x,activityFrame.location.y + (ActivityLayer?.frame.size.height)!)

            getActivityFrameOrigin()
            duration.endTime = getTime()
            
            createTextField()
            createCloseButton()
            
            myViews.append(ActivityLayer!)
                        
            activityFrame.height = 0
            let workingDetail = WorkingDetailsWindowController()
            workingDetail.tableViewObj=self
            workingDetail.showWindow(self)
            self.workingDetail=workingDetail
        }
        
    }
    
    

    /* Day to day Color Change in the TimeSheet */
    
    func tableView(tableView: NSTableView, viewForTableColumn tableColumn: NSTableColumn?, row: Int) -> NSView?
    {
        struct TokenContainer {
            static var token : dispatch_once_t = 0
        }
        
        dispatch_once(&TokenContainer.token) {
            self.displayDateInColHeader(self.date)
        }
        
        let view:NSView
        if tableColumn?.identifier == "tail"
        {
            view = myTableView.makeViewWithIdentifier("head", owner: self)!
        }
        else
        {
            view = myTableView.makeViewWithIdentifier("1", owner: self)!
        }
        
        view.wantsLayer = true
        view.layer?.backgroundColor = NSColor.clearColor().CGColor
        
        if tableColumn?.identifier == "1"
        {
            view.wantsLayer = true
            view.layer?.backgroundColor = NSColor(hue: 0.1, saturation: 0.2, brightness: 2.3, alpha: 3.0).CGColor
        }
        
        if tableColumn?.identifier == "2"
        {
            view.wantsLayer = true
            view.layer?.backgroundColor = NSColor(hue: 0.2, saturation: 0.1, brightness: 2.3, alpha: 3.0).CGColor
        }
        if tableColumn?.identifier == "3"
        {
            view.wantsLayer = true
            view.layer?.backgroundColor = NSColor(hue: 0.6, saturation: 0.1, brightness: 2.3, alpha: 3.0).CGColor
        }
        return view
    }
    
    
    /* Calender Window appearing as a popover in TimeSheet*/
    
    @IBOutlet var calender: NSButton!
    @IBAction func calender(sender: AnyObject)
    {
        popover.contentViewController = Calender()
        let calenderObj = popover.contentViewController as! Calender
        self.calenderObj = calenderObj
        self.calenderObj?.timeTableView = self
        
        if popover.shown{
            popover.performClose(sender)
        }
        else
        {
            popover.showRelativeToRect(calender.bounds, ofView: calender, preferredEdge: NSRectEdge.MaxY)
        }
    }
    
    /*  Current Time */
    
    func tick ()
    {
        currentTimeDisplayLabel.stringValue = NSDateFormatter.localizedStringFromDate(NSDate(), dateStyle: .NoStyle, timeStyle: .MediumStyle)
    }
    
    

    func drawDragView(){
            if activityFrame.location.x >= myTableView.frame.origin.x + (myTableView.frame.size.width)/8
            {
                
                
                ActivityLayer!.frame = NSMakeRect((activityFrame.cell?.origin.x)!,activityFrame.y,(activityFrame.cell?.size.width)!,activityFrame.height)
                
                checkOverlap()
                
                if flag
                {
                    
                     activityFrame.height = locationOfChangeTap.y - activityFrame.location.y
                    // preventing the activity frame height to become negative
                    if activityFrame.height < 0{
                        activityFrame.height = 0
                    }

                    ActivityLayer!.wantsLayer = true
                    ActivityLayer!.layer!.backgroundColor = NSColor.lightGrayColor().CGColor
                    ActivityLayer?.layer?.borderColor = NSColor.darkGrayColor().CGColor
                    ActivityLayer?.layer?.borderWidth = 1
                    
                    myTableView.addSubview(ActivityLayer!)
                    myTableView.addSubview(ActivityLayer!)
                    
                }
                scrollTableView()
                scrollVar += 1
                
            }
        }
    
    
    func scrollTableView()
    {
        if (ActivityLayer?.frame.origin.y)! - scrollView.contentView.bounds.origin.y
            + (ActivityLayer?.frame.size.height)! >= scrollView.contentView.bounds.size.height
        {
            scrollView.contentView.bounds.origin.y = scrollView.contentView.bounds.origin.y+30
            
            
        }
    }
    
    func checkOverlap(){
        if myViews.count != 0
        {
            
            for views in myViews
            {
                
                if CGRectIntersectsRect(NSMakeRect((ActivityLayer?.frame.origin.x)!, (ActivityLayer?.frame.origin.y)!, (ActivityLayer?.frame.size.width)!, (ActivityLayer?.frame.size.height)!+1),views.frame) || CGRectContainsPoint(views.frame, (ActivityLayer?.frame.origin)!){
                    
                    flag = false
                    break
                    
                }
                else
                {
                    flag = true
                }
            }
        }
        
    }
    
    func getActivityFrameOrigin()
    {
        activityFrame.row = myTableView.rowAtPoint(activityFrame.location)
        activityFrame.col = myTableView.columnAtPoint(activityFrame.location)
        
        
        activityFrame.cell = myTableView.frameOfCellAtColumn(activityFrame.col!, row: activityFrame.row!)
        if activityFrame.location.y >= activityFrame.cell!.origin.y && activityFrame.location.y < activityFrame.cell!.origin.y + (myTableView.rowHeight/4)
        {activityFrame.y = activityFrame.cell!.origin.y}
        if activityFrame.location.y >= activityFrame.cell!.origin.y + (myTableView.rowHeight/4) && activityFrame.location.y < activityFrame.cell!.origin.y + (myTableView.rowHeight/2){activityFrame.y = activityFrame.cell!.origin.y + (myTableView.rowHeight/4)}
        if activityFrame.location.y >= activityFrame.cell!.origin.y + (myTableView.rowHeight/2) && activityFrame.location.y < activityFrame.cell!.origin.y + (3 * myTableView.rowHeight/4){activityFrame.y = activityFrame.cell!.origin.y + (myTableView.rowHeight/2)}
        if activityFrame.location.y >= activityFrame.cell!.origin.y + (3 * myTableView.rowHeight/4) && activityFrame.location.y < activityFrame.cell!.origin.y + myTableView.rowHeight{activityFrame.y = activityFrame.cell!.origin.y + (3 * myTableView.rowHeight/4)
        }
    }
    func createTextField(){
        let myTextField = NSTextField(frame: NSMakeRect((ActivityLayer?.bounds.origin.x)!,(ActivityLayer?.bounds.height)!-myTableView.rowHeight/4,(ActivityLayer?.frame.size.width)!,myTableView.rowHeight/4))
        myTextField.editable = false
        myTextField.backgroundColor = NSColor.darkGrayColor()
        myTextField.bordered = false
        myTextField.stringValue = duration.startTime! + "-" + duration.endTime!
        ActivityLayer!.addSubview(myTextField)
    }
    func createCloseButton(){
        myButton = NSButton()
        myButton!.frame = NSMakeRect((ActivityLayer?.bounds.width)!-20,(ActivityLayer?.bounds.height)!-myTableView.rowHeight/4,20,myTableView.rowHeight/4)
        
        myButton!.title = "✖︎"
        myButton!.action = #selector(TimeTableView.buttonPressed(_:))
        myButton!.target = self
        
        ActivityLayer!.addSubview(myButton!)
        
    }
    
    func createDetailTextField() -> NSTextField{
        textView = NSTextField(frame: NSMakeRect((ActivityLayer?.bounds.origin.x)!,(ActivityLayer?.bounds.height)! - myTableView.rowHeight,(ActivityLayer?.bounds.width)! ,myTableView.rowHeight/4 * 3))
        textView?.editable = false
        textView?.backgroundColor = NSColor.lightGrayColor()
        textView?.bordered = false
        ActivityLayer?.addSubview(textView!)
        
        return textView!
    }
    
    func buttonPressed(sender : NSButton)
    {
        sender.superview?.removeFromSuperview()
        myViews.removeAtIndex(myViews.indexOf(sender.superview!)!)
    }
    
    
    
    
    func getTime() -> String{
        
        if activityFrame.row < 12{
            
            if activityFrame.row != 0{
                duration.hr = activityFrame.row
            }
            else{
                duration.hr = 12
            }
            duration.amPm = "a"
         }
            
        else{
            if activityFrame.row == 12{
                duration.hr = activityFrame.row!
            }
            else{
                duration.hr = activityFrame.row! - 12
            }
            duration.amPm = "p"
        }
        if activityFrame.row <= -1{
            duration.hr = 11
            duration.min = 59
            duration.amPm = "p"
        }
        
        if activityFrame.location.y >= activityFrame.cell!.origin.y && activityFrame.location.y < activityFrame.cell!.origin.y + (myTableView.rowHeight/4){ duration.min = 0}
        if activityFrame.location.y >= activityFrame.cell!.origin.y + (myTableView.rowHeight/4) && activityFrame.location.y < activityFrame.cell!.origin.y + (myTableView.rowHeight/2){ duration.min = 15}
        if activityFrame.location.y >= activityFrame.cell!.origin.y + (myTableView.rowHeight/2) && activityFrame.location.y < activityFrame.cell!.origin.y + (3 * myTableView.rowHeight/4){ duration.min = 30}
        if activityFrame.location.y >= activityFrame.cell!.origin.y + (3 * myTableView.rowHeight/4) && activityFrame.location.y < activityFrame.cell!.origin.y + myTableView.rowHeight{ duration.min = 45
        }
        return String(duration.hr!) + ":" + String(duration.min!) + duration.amPm!
        
    }

   /* Logout Button Action */
    
    @IBAction func logout(sender: NSButton)
    {
        
        loginWindowController!.showWindow(self)
        loginWindowController?.confirmPassword.hidden = true
        loginWindowController?.password.stringValue = ""
        loginWindowController?.indicator.stopAnimation(true)
        window?.close()
        
    }
    
  /* Submit Button Action */
    
    @IBAction func submit(sender: NSButton)
    {
        if sender.tag == 0
        {
            if Hours == 44
            {
                let alert = NSAlert()
                alert.messageText = "Done"
                alert.informativeText = "Weekly Report submitted successfully"
                alert.runModal()
                
                //sender.tag = 1
                sender.title = "Withdraw"
                sender.tag = 1
            }
            else
            {
                let alert = NSAlert()
                alert.messageText = "Done"
                alert.informativeText = "Please Fill Minimum  44 Hours"
                alert.runModal()
            }
        }
    }

    /* Report Module Calling Function*/
    
    @IBAction func reportButton(sender: NSButton)
    {
        self.window?.close()
        let mainWindowController = MainWindowController()
        mainWindowController.showWindow(self)
        self.mainWindowController = mainWindowController
    }
}
