//
//  ForgotPasswordWindow.swift
//  TimeTime
//
//  Created by medidi vv satyanarayana murty on 02/02/16.
//  Copyright © 2016 Medidi vv satyanarayana murty. All rights reserved.//

import Cocoa

class ForgotPasswordWindow: NSWindowController,NSWindowDelegate
{

    let keyChain = KeychainSwift()
   
    @IBOutlet var userNameInForgot: NSTextField!
    
    
    
    var loginWindowController:LoginWindow? = nil
    
    override func windowDidLoad()
    {
        window?.delegate = self
        super.windowDidLoad()
    }
//--------------------------SubmitButtonAction------------------------------------------------------
//-------------------------------------------------------------------------------------------------
    
    @IBAction func submit(sender: NSButton)
    {
        if userNameInForgot.stringValue != ""
        {
            if (checkLogin(userNameInForgot.stringValue, password: Keychain_keyName))
            {
                let username = NSUserDefaults.standardUserDefaults().valueForKey("username") as? String
                let password = keyChain.get("password")
                
                let alert = NSAlert()
                alert.messageText = "Data"
                alert.informativeText = "UserName is \(username!) and password is \(password!)"
                alert.runModal()
                
                userNameInForgot.stringValue = ""
                window?.close()
                loginWindowController!.confirmPassword.hidden = true
                loginWindowController!.showWindow(self)
            }
            else
            {
                let alert = NSAlert()
                alert .messageText = "Error"
                alert.informativeText = "Invalid UserName"
                alert.runModal()
                userNameInForgot.stringValue = ""
            }
        }
        else
        {
            let alert = NSAlert()
            alert.messageText = "Error"
            alert.informativeText = "UserName should not be Empty"
            alert.runModal()
        }
    }
    
    func checkLogin(username: String, password: String ) -> Bool
    {
        
        if (password == keyChain.get (Keychain_keyName)) || username == (NSUserDefaults.standardUserDefaults().valueForKey("username") as? String)!
        {
            return true
        }
        else
        {
            return false
        }
    }
    
    
    func windowWillResize(sender: NSWindow, toSize frameSize: NSSize) -> NSSize
    {
        return NSSize(width: 651.0, height:390.0)
    }
    @IBAction func cancel(sender: NSButton)
    {
        loginWindowController!.showWindow(self)
        window?.close()
    }
}
