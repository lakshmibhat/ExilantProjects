//
//  MainWindowController.swift
//  ReportTimeMacApp
//
//  Created by swathi m on 2/2/16.
//  Copyright © 2016 swathi m. All rights reserved.
//

import Cocoa
import EventKit

class MainWindowController: NSWindowController {
   
    @IBOutlet var reportView: NSView!
    @IBOutlet var resetButtonOutlet: NSButton!
    @IBOutlet var timePeriodOutlet: NSPopUpButton!
    @IBOutlet var projectNameOutlet: NSTextField!
    var abstractSearch : SecondWindowController?
    var detailSearch : DetailWindowController?
    var timeTableView : TimeTableView?
    @IBOutlet var detailRadioButtonOutlet: NSButton!
    @IBOutlet var abstractRadioButtonOutlet: NSButton!
    
    @IBOutlet var timeSheetStatusItemListOutlet: NSPopUpButton!
    
    @IBOutlet var searchButtonOutlet: NSButton!
    
    @IBOutlet var generateButtonOutlet: NSButton!
    override var windowNibName : String? {
        return "MainWindowController"
    }
    
    
    @IBAction func resetButtonAction(sender: NSButton) {
      
    }
    
    
    @IBAction func searchButtonAction(sender: NSButton) {
        if (abstractRadioButtonOutlet.integerValue == 1){
        abstractSearch = SecondWindowController(windowNibName: "SecondWindowController")
        window?.beginSheet(abstractSearch!.window!, completionHandler: nil)
        }
        else {
            detailSearch = DetailWindowController(windowNibName: "DetailWindowController")
            window?.beginSheet(detailSearch!.window!, completionHandler: nil)
        }
    }
    
    @IBAction func mainWindowCloseButton(sender: NSButton) {
        window?.close()
        let timeTableView = TimeTableView()
        timeTableView.showWindow(self)
        self.timeTableView = timeTableView
        
    }
    @IBAction func abstractDetailButtonAction(sender: NSButton) {
        if (sender.tag == 0)
        {
            abstractRadioButtonOutlet.integerValue=1
            
        }
        else
        {
            detailRadioButtonOutlet.integerValue = 1
        }
        
    }
    
    override func windowDidLoad() {
        super.windowDidLoad()
       reportView.wantsLayer = true
        reportView.layer?.backgroundColor = NSColor.lightGrayColor().CGColor
    }
        
}
