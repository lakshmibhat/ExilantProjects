//
//  Calender.swift
//  TimeApp
//
//  Created by medidi vv satyanarayana murty on 14/03/16.
//  Copyright © 2016 medidi vv satyanarayana murty. All rights reserved.
//

import Cocoa

class Calender: NSViewController
{
    var timeTableView: TimeTableView? = nil
    @IBOutlet var calender: NSDatePicker!
    override var nibName: String?{
        return "Calender"
    }
    
    var dateVar : NSDate?

    
    @IBAction func closeCalender(sender: NSButton) {
        calender.window?.close()
    }
    @IBAction func getDate(sender: AnyObject) {
        let currDate = NSDate()
        if(calender.dateValue.isGreaterThan(currDate)){
            
        }
        else {

        dateVar = sender.dateValue
        timeTableView?.displayDateInColHeader(dateVar!)
        NSNotificationCenter.defaultCenter().postNotificationName("load", object: nil)
        calender.window?.close()
        }
    }
    override func viewDidLoad()
    {
        super.viewDidLoad()
        let todaysDate:NSDate = NSDate()
        calender.dateValue = todaysDate
    }
}
