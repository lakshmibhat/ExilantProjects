//
//  WorkingDetailsWindowController.swift
//  TimeMacApp
//
//  Created by lakshmi r bhat on 02/02/16.
//  Copyright © 2016 Exilant. All rights reserved.
//

import Cocoa

class WorkingDetailsWindowController: NSWindowController {
    var subWC:AddSubWindowController?
    var result:Int?
    var result1:Int?
    var coreData:CoreDataFile?
    var tableViewObj:TimeTableView?
    var truncatedStartTime : String?
    var truncatedEndTime : String?
    var detailTextView : String?

    
    @IBOutlet weak var taskGroupOutlet: NSPopUpButton!
    @IBOutlet weak var groupOutlet: NSPopUpButton!
    @IBOutlet weak var workTimeOutlet: NSTextField!
    var count:Int=0
    @IBOutlet weak var Box: NSBox!
    @IBOutlet weak var HomeRadio: NSButton!
    @IBOutlet weak var OfficeRadio: NSButton!
    @IBOutlet weak var CurrentDate: NSTextField!
    @IBOutlet weak var workDescription: NSTextField!
    @IBOutlet weak var activityOutlet: NSPopUpButton!
    
    
    @IBOutlet weak var unAccounted: NSTextField!
    @IBOutlet weak var endTime: NSTextField!
    @IBOutlet weak var startTime: NSTextField!
    
    
    
    @IBAction func Add(sender: NSButton) {
if(!workDescription.stringValue.isEmpty)
{
    subWC = AddSubWindowController()
    subWC?.coreData=coreData!

        window?.beginSheet(subWC!.window!, completionHandler: nil)
}
    
else{
    
    let alert = NSAlert()
    alert.messageText = "Warning"
    alert.informativeText = "Enter the work description"
    alert.addButtonWithTitle("OK")
    alert.runModal()
    }
}
    @IBAction func officeHomeAction(sender: NSButton) {
        if(sender.tag==0){
            OfficeRadio.integerValue=1
        }
        else{
            HomeRadio.integerValue=1
        }
    }
   
   

    
    override func windowDidLoad() {
        super.windowDidLoad()
        
        let todaysDate:NSDate = NSDate()
        let formatter = NSDateFormatter()
        formatter.dateFormat = "dd-MMM-yyyy"
        let date = formatter.stringFromDate(todaysDate)
        CurrentDate.stringValue=date

        updateTime()

        startTime.stringValue = truncatedStartTime!
        endTime.stringValue = truncatedEndTime!
        updateWorkHour()
        self.window?.backgroundColor = NSColor.whiteColor()
        coreData=CoreDataFile()

       // Implement this method to handle any initialization after your window controller's window has been loaded from its nib file.
    }
    override var windowNibName:String?
        {
        return "WorkingDetailsWindowController"
    }
    @IBAction func cancel(sender: NSButton) {
        if workDescription.stringValue.isEmpty{
            window?.close()
            tableViewObj?.buttonPressed((tableViewObj?.myButton)!)

            
          //  exit(0)
        }
        else{
            let alert = NSAlert()
            alert.messageText = "Warning"
            alert.informativeText = "Unsaved Data: Any data entered or changed will not be saved. Do you still want to continue?"

            alert.addButtonWithTitle("Yes")
            alert.addButtonWithTitle("No")

            let result = alert.runModal()
            switch result {
            case NSAlertFirstButtonReturn:
                // The user clicked "Yes"
                self.window?.close()
                tableViewObj?.buttonPressed((tableViewObj?.myButton)!)

                //exit(0)

                break
            case NSAlertSecondButtonReturn: break
                // The user clicked "No"
            default: break
            }        }
    }


    func updateTime() {
        let startTimeCh = tableViewObj?.duration.startTime!.characters.split{$0==":"}.map{String($0)}
        if ((tableViewObj?.duration.startTime?.characters.last) == "p" && Int(startTimeCh![0]) != 12){
            let a = Int(startTimeCh![0])!+12
            let newStartTime = String(a) + ":" + startTimeCh![1]
            truncatedStartTime = newStartTime.substringToIndex((newStartTime.endIndex.predecessor()))
        }
        else if (Int(startTimeCh![0]) == 12 && (tableViewObj?.duration.startTime?.characters.last) == "a"){
            let a = "00"
            let newStartTime = String(a) + ":" + startTimeCh![1]
            truncatedStartTime = newStartTime.substringToIndex((newStartTime.endIndex.predecessor()))
        }
        else{
            truncatedStartTime = tableViewObj?.duration.startTime!.substringToIndex((tableViewObj?.duration.startTime!.endIndex.predecessor())!)
        }
        let endTimeCh = tableViewObj?.duration.endTime!.characters.split{$0==":"}.map{String($0)}
        
        if ((tableViewObj?.duration.endTime?.characters.last)! == "p" && Int(endTimeCh![0]) != 12) {
            let a = Int(endTimeCh![0])!+12
            let newEndTime = String(a) + ":" + endTimeCh![1]
            truncatedEndTime = newEndTime.substringToIndex((newEndTime.endIndex.predecessor()))
        }
        else{
            truncatedEndTime = tableViewObj?.duration.endTime!.substringToIndex((tableViewObj?.duration.endTime!.endIndex.predecessor())!)
        }
    }
    
    func updateWorkHour(){
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "HH:mm"
        let startArr=startTime.stringValue.characters.split{$0==":"}.map{String($0)}
        let start = Int(startArr[0])!*60+Int(startArr[1])!

        let endArr=endTime.stringValue.characters.split{$0 == ":"}.map{String($0)}
        let end = Int(endArr[0])!*60+Int(endArr[1])!
                result = end - start
        if result < 0{
            result = result! + (12*60)
        }
            let resultString=convertIntToDateFormat(result!)
        workTimeOutlet.stringValue = resultString
    }
    func updateUnAccounted()->String{
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "HH:mm"
        let startArr=startTime.stringValue.characters.split{$0==":"}.map{String($0)}
        let start = Int(startArr[0])!*60+Int(startArr[1])!
        
        let endArr=endTime.stringValue.characters.split{$0 == ":"}.map{String($0)}
        let end = Int(endArr[0])!*60+Int(endArr[1])!
        
        result1 = end - start
        let workTimeArr=workTimeOutlet.stringValue.characters.split{$0 == "."}.map{String($0)}
        let workTime = Int(workTimeArr[0])!*60+Int(workTimeArr[1])!

        result=result1!-workTime
        return convertIntToDateFormat(result!)
    }

    func convertIntToDateFormat(result:Int)->String{
        let hours = (result / 60)

        let minutes = result % 60
        
        return NSString(format: "%0.2d.%0.2d",hours,minutes) as String
        
    }
    
    
    @IBAction func startDec(sender: NSButton) {
        let dateFormatter = NSDateFormatter()

        dateFormatter.dateFormat = "HH:mm"

        let date = dateFormatter.dateFromString(startTime.stringValue)
//        var str_from_date = dateFormatter.stringFromDate (date!)
        startTime.stringValue = dateFormatter.stringFromDate((date?.dateByAddingTimeInterval(-15.0*60.0))!)
        unAccounted.stringValue=updateUnAccounted()
    }

    @IBAction func startInc(sender: NSButton) {
//        startTime.integerValue=startTime.integerValue+0.15
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "HH:mm"
        let date = dateFormatter.dateFromString(startTime.stringValue)
        //        var str_from_date = dateFormatter.stringFromDate (date!)
        startTime.stringValue = dateFormatter.stringFromDate((date?.dateByAddingTimeInterval(15.0*60.0))!)
        unAccounted.stringValue=updateUnAccounted()

    }

    @IBAction func endDec(sender: NSButton) {
        let dateFormatter = NSDateFormatter()
        
        dateFormatter.dateFormat = "HH:mm"
        
        let date = dateFormatter.dateFromString(endTime.stringValue)
        //        var str_from_date = dateFormatter.stringFromDate (date!)
        endTime.stringValue = dateFormatter.stringFromDate((date?.dateByAddingTimeInterval(-15.0*60.0))!)
        unAccounted.stringValue=updateUnAccounted()

    }
    
    
    @IBAction func endInc(sender: NSButton) {
        let dateFormatter = NSDateFormatter()
        
        dateFormatter.dateFormat = "HH:mm"
        
        let date = dateFormatter.dateFromString(endTime.stringValue)
        //        var str_from_date = dateFormatter.stringFromDate (date!)
        endTime.stringValue = dateFormatter.stringFromDate((date?.dateByAddingTimeInterval(15.0*60.0))!)
        unAccounted.stringValue=updateUnAccounted()

    }
    
    @IBAction func workTimeAction(sender: NSTextField) {
        unAccounted.stringValue=updateUnAccounted()
    }


    @IBAction func doneButton(sender: NSButton) {
        coreData?.insert(groupOutlet.titleOfSelectedItem!, taskGroup: taskGroupOutlet.titleOfSelectedItem!, workDetail: workDescription.stringValue)
        coreData?.fetch()
        tableViewObj?.createDetailTextField().stringValue  = groupOutlet.titleOfSelectedItem! + " " + taskGroupOutlet.titleOfSelectedItem! + " " + workTimeOutlet.stringValue

        window?.close()
    }

}
