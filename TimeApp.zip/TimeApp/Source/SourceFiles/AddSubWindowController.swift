//
//  AddSubWindowController.swift
//  TimeMacApp
//
//  Created by lakshmi r bhat on 04/02/16.
//  Copyright © 2016 Exilant. All rights reserved.
//

import Cocoa
//import CoreDataFunctions
class AddSubWindowController: NSWindowController {
    var coreData:CoreDataFile?

    @IBOutlet weak var groupOtlet: NSPopUpButton!
    @IBOutlet weak var workDetail: NSTextField!
    @IBOutlet weak var taskGroupOutlet: NSPopUpButton!
    var workingDetail = AppDelegate()
   
    override func windowDidLoad() {
        super.windowDidLoad()
        self.window?.backgroundColor=NSColor.whiteColor()
        // Implement this method to handle any initialization after your window controller's window has been loaded from its nib file.
        
    }
    override var windowNibName:String?{
        return "AddSubWindowController"
    }
    
    @IBAction func back(sender: NSButton) {
//        print("back")

        window?.close()
    }
    
    @IBAction func saveButton(sender: NSButton) {
        
        groupOtlet.titleOfSelectedItem!
        coreData?.insert(groupOtlet.titleOfSelectedItem!, taskGroup: taskGroupOutlet.titleOfSelectedItem!, workDetail: workDetail!.stringValue)

        window?.close()
    }
    
}
