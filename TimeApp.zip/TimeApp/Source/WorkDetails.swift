//
//  WorkDetails.swift
//  TimeApp
//
//  Created by swathi m on 3/31/16.
//  Copyright © 2016 medidi vv satyanarayana murty. All rights reserved.
//

import Foundation
import CoreData


class WorkDetails: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
