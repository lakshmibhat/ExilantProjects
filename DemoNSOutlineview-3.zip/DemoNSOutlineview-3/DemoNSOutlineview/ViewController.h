//
//  ViewController.h
//  DemoNSOutlineview
//
//  Created by trainer mac on 30/12/15.
//  Copyright © 2015 Exilant. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController
@property (weak) IBOutlet NSOutlineView *bookOutlineview;

@end

