//
//  Book.m
//  DemoNSOutlineview
//
//  Created by avnish kumar on 31/12/15.
//  Copyright © 2015 Exilant. All rights reserved.
//

#import "Book.h"

@implementation Book
-(id)initWithName:(NSString*)name author:(NSString*)author price:(float)price year:(int)year
{
    if(self=[super init])
    {
        _name=name;
        _author=author;
        _price=price;
        _year=year;
        
    }
    return self;
}

@end
