//
//  Book.h
//  DemoNSOutlineview
//
//  Created by avnish kumar on 31/12/15.
//  Copyright © 2015 Exilant. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Book : NSObject
@property NSString *name;
@property NSString *author;
@property float price;
@property int year;
-(id)initWithName:(NSString*)name author:(NSString*)author price:(float)price year:(int)year;
@end
