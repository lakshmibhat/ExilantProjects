//
//  ViewController.m
//  DemoNSOutlineview
//
//  Created by trainer mac on 30/12/15.
//  Copyright © 2015 Exilant. All rights reserved.
//

#import "ViewController.h"
#import "Author.h"
#import "Book.h"


@interface ViewController()
{
    NSDictionary *firstParent;

    IBOutlet NSArrayController *bookDetails;
    NSMutableArray *array;
    NSArray *books;
    NSArray *list;
    Author *selectedAuthor;
    NSDictionary *publication;
    
}
@property (weak) IBOutlet NSTextField *nameText;
@property (weak) IBOutlet NSTextField *addressText;
@property (weak) IBOutlet NSTextField *phoneNo;
@property (weak) IBOutlet NSTableView *tableView;

-(void) booksForSelectedAuthor;

@end


@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    array=[[NSMutableArray alloc]init];
    
    Author *author1=[[Author alloc]initWithName:@"avnish" address:@"Kengeri" phNo:@"8050150178"];
    Author *author2=[[Author alloc]initWithName:@"manish" address:@"patna" phNo:@"8147322419"];
    Author *author3=[[Author alloc]initWithName:@"nishant" address:@"upnagara" phNo:@"9234836562"];
    Author *author4=[[Author alloc]initWithName:@"sonu" address:@"yelahanka" phNo:@"9204375239"];
    
    Book *book1=[[Book alloc]initWithName:@"book1" author:@"avnish" price:1000.0 year:2000];
    Book *book2=[[Book alloc]initWithName:@"book2" author:@"avnish" price:900.0 year:2005];
    Book *book3=[[Book alloc]initWithName:@"book3" author:@"avnish" price:1000.0 year:2006];
    
    Book *book4=[[Book alloc]initWithName:@"book4" author:@"manish" price:800.0 year:2003];
    Book *book5=[[Book alloc]initWithName:@"book5" author:@"manish" price:600.0 year:2001];
    Book *book6=[[Book alloc]initWithName:@"book6" author:@"manish" price:700.0 year:2005];
    
    Book *book7=[[Book alloc]initWithName:@"book7" author:@"nishant" price:100.0 year:2010];
    Book *book8=[[Book alloc]initWithName:@"book8" author:@"nishant" price:200.0 year:2011];
    Book *book9=[[Book alloc]initWithName:@"book9" author:@"nishant" price:300.0 year:2012];
    
    Book *book10=[[Book alloc]initWithName:@"book10" author:@"sonu" price:100.0 year:2010];
    Book *book11=[[Book alloc]initWithName:@"book11" author:@"sonu" price:200.0 year:2011];
    Book *book12=[[Book alloc]initWithName:@"book12" author:@"sonu" price:300.0 year:2012];
    
    books=[[NSArray alloc]initWithObjects:book1,book2,book3,book4,book5,book6,book7,book8,book9,book10,book11,book12, nil];
    

    
    
    
    firstParent = [[NSDictionary alloc] initWithObjectsAndKeys:@"author",@"parent",[NSArray arrayWithObjects:author1,author2,author3,author4, nil],@"children", nil];
    
   
    list = [NSArray arrayWithObjects:firstParent, nil];
    
    

}


- (BOOL)outlineView:(NSOutlineView *)outlineView isItemExpandable:(id)item
{
    if ([item isKindOfClass:[NSDictionary class]] || [item isKindOfClass:[NSArray class]]) {
        return YES;
    }else {
        return NO;
    }
}


- (NSInteger)outlineView:(NSOutlineView *)outlineView numberOfChildrenOfItem:(id)item
{
    
    if (item == nil) { //item is nil when the outline view wants to inquire for root level items
        return [list count];
    }
    
    if ([item isKindOfClass:[NSDictionary class]]) {
        return [[item objectForKey:@"children"] count];
    }
    
    return 0;
}

- (id)outlineView:(NSOutlineView *)outlineView child:(NSInteger)index ofItem:(id)item
{
    
    if (item == nil) { //item is nil when the outline view wants to inquire for root level items
        return [list objectAtIndex:index];
    }
    
    if ([item isKindOfClass:[NSDictionary class]]) {
        Author *author= [[item objectForKey:@"children"] objectAtIndex:index];
        return author.name;
    }
    
    return nil;
}


- (void)outlineViewSelectionDidChange:(NSNotification *)notification{
    
    
    NSInteger no=[notification.object selectedRow];
    
    //NSString *authorName = [notification.object itemAtRow:no];
    
    
  
    
    NSLog(@"%@",notification.object);
    selectedAuthor=[[firstParent objectForKey:@"children"] objectAtIndex:no-1];
    
    NSLog(@"%@%@%@",selectedAuthor.name,selectedAuthor.address,selectedAuthor.phNo);
    
    self.nameText.stringValue=selectedAuthor.name;
    self.addressText.stringValue=selectedAuthor.address;
    self.phoneNo.stringValue=selectedAuthor.phNo;
    
    
    [self booksForSelectedAuthor];
    
}


-(void)booksForSelectedAuthor
{
    if(array.count)
    {
        [bookDetails removeObjects:array];

    }
    
    
    NSInteger count=array.count;
    for (int i=0;i<count; i++)
    {
        [array removeObjectAtIndex:0];
    }
   
    
    for (int i=0;i<books.count; i++)
    {
        if([[books objectAtIndex:i] author]==selectedAuthor.name)
        {
            [array addObject:[books objectAtIndex:i]];
        }
    }
    
    
    

     [bookDetails addObjects:array];
//    [bookDetails removeObjects:self.array];
//    [bookDetails addObjects:self.array];
}



- (id)outlineView:(NSOutlineView *)outlineView objectValueForTableColumn:(NSTableColumn *)theColumn byItem:(id)item
{
    
    if ([[theColumn identifier] isEqualToString:@"children"])
    { 
        if ([item isKindOfClass:[NSDictionary class]]) {
            return @"Author";        }
        return item;
    }
    else {
        if ([item isKindOfClass:[NSDictionary class]])
        {
            return [item objectForKey:@"parent"];
        }
    }
    
    return nil;
}


@end
