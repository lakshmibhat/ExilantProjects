//
//  Author.h
//  DemoNSOutlineview
//
//  Created by avnish kumar on 31/12/15.
//  Copyright © 2015 Exilant. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Author : NSObject
@property NSString *name;
@property NSString *address;
@property NSString *phNo;
-(id)initWithName:(NSString*)name address:(NSString*)address phNo:(NSString*)phNo;
@end
