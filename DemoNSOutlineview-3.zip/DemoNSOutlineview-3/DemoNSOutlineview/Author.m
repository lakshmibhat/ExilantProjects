//
//  Author.m
//  DemoNSOutlineview
//
//  Created by avnish kumar on 31/12/15.
//  Copyright © 2015 Exilant. All rights reserved.
//

#import "Author.h"

@implementation Author
-(id)initWithName:(NSString*)name address:(NSString*)address phNo:(NSString*)phNo
{
    if(self=[super init])
    {
        _name=name;
        _address=address;
        _phNo=phNo;
        
    }
    return self;
}
@end
