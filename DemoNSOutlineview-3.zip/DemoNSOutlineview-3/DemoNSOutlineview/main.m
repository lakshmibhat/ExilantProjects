//
//  main.m
//  DemoNSOutlineview
//
//  Created by trainer mac on 30/12/15.
//  Copyright © 2015 Exilant. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
