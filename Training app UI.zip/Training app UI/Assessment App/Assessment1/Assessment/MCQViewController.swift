//
//  MCQViewController.swift
//  Assessment
//
//  Created by lakshmi r bhat on 06/06/16.
//  Copyright © 2016 Exilant. All rights reserved.
//

import UIKit

class MCQViewController: UIViewController, UITextViewDelegate{
    let checkedImage = UIImage(named: "checked.png")! as UIImage
    let uncheckedImage = UIImage(named: "unchecked.png")! as UIImage
    var isChecked: Bool = false
    var placeholderLabel:UILabel!
    var coreData:CoreDataFile?
    var answer:String!
    var assessmentObj:AssessmentTableViewController?
    var count = 0
    var MCQList :MCQListTableViewController?
    
    @IBOutlet weak var textView: UITextView!
   
    @IBOutlet weak var button1: UIButton!

    @IBOutlet weak var button2: UIButton!

    @IBOutlet weak var button3: UIButton!
    
    @IBOutlet weak var button4: UIButton!
    
    
    @IBOutlet weak var option1: UITextField!
    
    @IBOutlet weak var option2: UITextField!
    
    @IBOutlet weak var option3: UITextField!
    
    @IBOutlet weak var option4: UITextField!
    
    @IBOutlet weak var descrption: UITextField!
  
    @IBOutlet weak var nextBTN: UIButton!
  
    @IBOutlet weak var queNumber: UILabel!
    
    @IBOutlet weak var warningLabel: UILabel!
       override func viewDidLoad() {
        super.viewDidLoad()
        coreData=CoreDataFile()
        reloadView()
        // Do any additional setup after loading the view.
    }
   
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
        // Dispose of any resources that can be recreated.
    }
//    func textViewDidChange(textView: UITextView) {
//        placeholderLabel.hidden = !textView.text.isEmpty
//    }
    
    @IBAction func buttonClicked(sender: UIButton) {
        if sender.tag == button1.tag{
            button1.setImage(checkedImage, forState: .Normal)
            button2.setImage(uncheckedImage, forState: .Normal)
            button3.setImage(uncheckedImage, forState: .Normal)
            button4.setImage(uncheckedImage, forState: .Normal)
        }
        if sender.tag == button2.tag{
            button2.setImage(checkedImage, forState: .Normal)
            button1.setImage(uncheckedImage, forState: .Normal)
            button3.setImage(uncheckedImage, forState: .Normal)
            button4.setImage(uncheckedImage, forState: .Normal)
        }
        if sender.tag == button3.tag{
            button3.setImage(checkedImage, forState: .Normal)
            button1.setImage(uncheckedImage, forState: .Normal)
            button2.setImage(uncheckedImage, forState: .Normal)
            button4.setImage(uncheckedImage, forState: .Normal)
        }
        if sender.tag == button4.tag{
            button4.setImage(checkedImage, forState: .Normal)
            button2.setImage(uncheckedImage, forState: .Normal)
            button3.setImage(uncheckedImage, forState: .Normal)
            button1.setImage(uncheckedImage, forState: .Normal)
        }
    }
    
    func reloadView()
    {
        warningLabel.text = nil
        textView.text = nil
//        placeholderLabel = UILabel()
//        placeholderLabel.text = "Enter Question Here"
//        placeholderLabel.font = UIFont.italicSystemFontOfSize(textView.font!.pointSize)
//        placeholderLabel.sizeToFit()
//        textView.addSubview(placeholderLabel)
//        placeholderLabel.frame.origin = CGPointMake(5, textView.font!.pointSize / 2)
//        placeholderLabel.textColor = UIColor(white: 0, alpha: 0.3)
//        placeholderLabel.hidden = !textView.text.isEmpty
        option1.text = nil
        option2.text = nil
        option3.text = nil
        option4.text = nil
        descrption.text = nil
        button1.setImage(uncheckedImage, forState: .Normal)
        button2.setImage(uncheckedImage, forState: .Normal)
        button3.setImage(uncheckedImage, forState: .Normal)
        button4.setImage(uncheckedImage, forState: .Normal)
        count += 1
        queNumber.text = String(count)
    }
    
    @IBAction func nextButton(sender: UIButton) {
        
        if button1.currentImage == checkedImage{
           answer = option1.text
        }
        else if button2.currentImage == checkedImage{
            answer = option2.text
        }
        else if button3.currentImage == checkedImage{
            answer = option3.text
        }
        else if button4.currentImage == checkedImage{
            answer = option4.text
        }
        if textView.text.isEmpty {
            textView.subviews[0].hidden = false
        }
        else{
            textView.subviews[0].hidden = true
        }
        if answer == nil {
            warningLabel.text = "Check the correct answer"
            warningLabel.textColor = UIColor.redColor()
            let alertController = UIAlertController(title: "Alert", message:
                "Check correct answer", preferredStyle: UIAlertControllerStyle.Alert)
            alertController.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default,
                handler: nil))
            self.presentViewController(alertController, animated: true, completion: nil)
        }
        else{
        if textView.subviews[0].hidden == false || option1.text == "" || option2.text == "" || option3.text == "" || option4.text == ""{
            let alertController = UIAlertController(title: "Alert", message:
                "Enter Question and options properly", preferredStyle: UIAlertControllerStyle.Alert)
            alertController.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default,
                handler: nil))
            self.presentViewController(alertController, animated: true, completion: nil)
        }
        else{
        coreData?.insert(textView.text, option1: option1.text!, option2: option2.text!, option3: option3.text!, option4: option4.text!, description: descrption.text! , answer: answer, noOfQue: String(count))
            reloadView()

        }
        }
    }

  
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "PreviewSegue" {
                let destinationController = segue.destinationViewController as! MCQListTableViewController
            coreData?.fetch()

                destinationController.multiples = (coreData?.array)!
            destinationController.mcq = self

        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
