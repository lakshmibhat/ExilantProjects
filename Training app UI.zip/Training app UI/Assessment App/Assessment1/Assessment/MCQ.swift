//
//  MCQ.swift
//  Assessment
//
//  Created by lakshmi r bhat on 14/06/16.
//  Copyright © 2016 Exilant. All rights reserved.
//

import Foundation
import CoreData


class MCQ: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
